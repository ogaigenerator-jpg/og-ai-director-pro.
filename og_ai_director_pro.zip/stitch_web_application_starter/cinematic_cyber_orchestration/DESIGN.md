---
name: Cinematic Cyber-Orchestration
colors:
  surface: '#0e1321'
  surface-dim: '#0e1321'
  surface-bright: '#343948'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#161b2a'
  surface-container: '#1a1f2e'
  surface-container-high: '#252a39'
  surface-container-highest: '#303444'
  on-surface: '#dee2f6'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#dee2f6'
  inverse-on-surface: '#2b303f'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#4fdbc8'
  on-secondary: '#003731'
  secondary-container: '#04b4a2'
  on-secondary-container: '#003f38'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e79400'
  on-tertiary-container: '#563400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0e1321'
  on-background: '#dee2f6'
  surface-variant: '#303444'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-desktop: 1rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style
The design system powers an enterprise-grade, real-time AI cinema orchestration suite designed for directors, technical artists, and visual futurists. The emotional posture balances precision cockpit instrumentation with dark cinematic mystery: surgical, hyper-responsive, and commanding. 

The aesthetic fuses **Futuristic Glassmorphic Cockpit** with **Technical High-Density Minimal HUD**. The canvas recedes into deep void-level obsidians, ensuring visual render previews, generative frame timelines, and prompt matrices command complete hierarchy. Interfaces do not mimic generic consumer SaaS; they draw cues from professional post-production hardware, digital intermediate (DI) color suites, and cybernetic avionics. Semi-translucent panels, hairline glassmorphic borders with dynamic light refraction, laser-sharp monospaced data streams, and disciplined neon-accented telemetry create an immersive, low-fatigue environment for long editing and generative prompting sessions.

## Colors
The palette leverages a deep spectral hierarchy tuned specifically for wide color gamut displays and HDR video workflows.

- **Obsidian Voids & Foundations (`#070b14`, `#0a0f1d`)**: The structural base. Avoid true black (`#000000`) for surfaces to prevent OLED smearing and harsh contrast breaks; instead, rely on cold-shifted cosmic obsidian that allows multi-tiered frosted panels (`#0d1527` with alpha blends) to float effortlessly.
- **Electric Cyan & Teal (`#06b6d4`, `#14b8a6`)**: Primary interactive and synthesis state drivers. Cyan represents active model compute, selected camera vectors, and real-time generation paths. Teal delivers grounding secondary states, node graph connections, and confirmed parameters.
- **Amber Gold Highlights (`#f59e0b`, `#fbbf24`)**: High-priority alert states, render markers, frame-lock points, keyframe nodes, and executive-level overrides. Amber is deployed sparingly as a hot luminous accent against the cool abyss.
- **Slate Borders & Gridlines (`#1e293b`, `#334155`)**: Subdued structural boundaries with varying opacity (from 15% to 40%) that give components their signature etched-glass, HUD-frame identity without competing against generative media content.

## Typography
The typographic architecture implements a strict three-tier role taxonomy:

1. **Display & Viewport Directives (Plus Jakarta Sans)**: Used exclusively for section anchors, studio suite designations, dynamic modal headers, and main view states. Geometric, clean, and modern without decorative distraction.
2. **System Interface & Production Prose (Inter)**: Handles descriptive metadata, parameter tooltips, collaboration dialogues, script notes, and AI prompt engineering fields. Neutral and hyper-legible under low-illumination viewing conditions.
3. **Studio HUD & Telemetry Badges (JetBrains Mono)**: Drives frame timecodes (`00:04:22:18`), seed parameters, token usage counts, aspect ratios (`2.39:1`), model weights, and prompt status tags. Rendered in all-caps for micro-labels with expanded tracking for maximum instant scanability.

## Layout & Spacing
The layout model employs an ultra-dense, multi-panel fluid grid engineered for multi-monitor studio workstations, widescreen production displays, and tablet companion controllers.

- **Grid Strategy**: Fluid layout anchored by dockable horizontal and vertical viewports (Node Graph canvas, 3D Camera Frustum, Multi-Track Prompt Timeline, and Asset Sequencer). 
- **Density & Modularity**: The base spacing unit is based on a rigid 4px micro-increment, prioritizing tight spatial economy. Desktop interfaces feature fixed side rails (tools: 56px, inspector: 320px–380px) flanked by fluid workspace containers.
- **Breakpoints**:
  - `Desktop (>= 1280px)`: Full multi-pane orchestration matrix. Gutters locked at `gutter-desktop` (16px) with dynamic inner sub-grid modules.
  - `Tablet (768px – 1279px)`: Side inspector collapses to an off-canvas glass drawer; timeline prioritizes scrubbing mode over granular node editing; margin drops to `1rem` (16px).
  - `Mobile (< 768px)`: Companion monitoring view: viewport stacks vertically over timeline markers; tool palettes collapse to bottom fixed thumb-cockpits.

## Elevation & Depth
Elevation abandons traditional soft drop shadows in favor of **Luminescent Spectral Layering** and **Glassmorphic Obsidian Planes**. Visual height is communicated through material opacity, internal highlight illumination, and edge luminescence:

- **Level 0 (Canvas Void)**: Base tone `#070b14` with a subtle technical dot-grid pattern (`rgba(6, 182, 212, 0.04)` at 24px intervals).
- **Level 1 (Docked Structural Surfaces)**: Background `rgba(10, 15, 29, 0.75)`, 1px border `rgba(30, 41, 59, 0.5)`, backdrop blur `12px`.
- **Level 2 (Floating Cockpit Palettes & Overlays)**: Background `rgba(13, 21, 39, 0.85)`, 1px border `rgba(6, 182, 212, 0.25)`, backdrop blur `20px`, surface highlight inner glow `inset 0 1px 0 0 rgba(255, 255, 255, 0.08)`.
- **Level 3 (Modal Alerts, Active Lens Inspector, Keyframe Overrides)**: Background `rgba(15, 23, 42, 0.95)`, 1px border `rgba(245, 158, 11, 0.4)`, ambient cyan drop-glow `0 8px 32px -4px rgba(6, 182, 212, 0.15)`.
- **Dynamic HUD Glint**: Elements receive a top border hairline gradient (`linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.4), transparent)`) to simulate light grazing cybernetic glass.

## Shapes
To preserve the precision instrumentation identity of a professional studio terminal, corners remain crisp and controlled (`roundedness: 1`). 

- Default interactive controls, timeline clips, and input cells use `4px` (`0.25rem`) corner radiuses.
- Primary floating panels, inspector drawers, and media preview frames use `8px` (`0.5rem`).
- Technical HUD chip tags, prompt status badges, and telemetry pills utilize chamfered corner cuts (via 45-degree clip-path notches) or controlled `2px` micro-radiuses to maintain a tactical, industrial feel. Fully round/pill shapes are strictly reserved for live recording and playback playhead needles.

## Components

### Buttons & Trigger Controls
- **Primary Studio Action (Render, Dispatch AI Pass)**: Background filled with high-intensity gradient `linear-gradient(135deg, #06b6d4, #14b8a6)`. Typography in deep obsidian `#070b14` font-weight `600`. Outer glow on hover (`0 0 16px rgba(6, 182, 212, 0.4)`).
- **Secondary Cockpit Button**: Ghost obsidian background `rgba(10, 15, 29, 0.6)` with a 1px border in `rgba(51, 65, 85, 0.8)`. Hover transitions border to cyan `#06b6d4` with text color shifting from `#94a3b8` to `#ffffff`.
- **Warning/Override Action**: Outlined in amber `#f59e0b` with `rgba(245, 158, 11, 0.08)` fill, scaling to glowing amber on focus.

### Input Fields & Parameter Steppers
- Matte obsidian base (`#070b14`) sunken beneath panel surfaces. 1px border in `rgba(30, 41, 59, 0.8)`.
- Text styled in `Inter` body-md, with attached unit meters (`px`, `fps`, `cfg`, `steps`) set in `JetBrains Mono` label-sm colored `#64748b`.
- Active focus state shifts the border to `#06b6d4` with a subtle inner cyan shadow (`inset 0 0 6px rgba(6, 182, 212, 0.2)`).

### HUD Chips, Status Tags & Monospace Nodes
- Ultra-compact tags built with `JetBrains Mono` label-sm in full caps.
- Backgrounds use dark tinted glass: `rgba(6, 182, 212, 0.1)` for cyan tags (AI ready/generating), `rgba(245, 158, 11, 0.1)` for amber tags (keyframe/rendered/locked), framed with a matching 1px border at 40% opacity.

### Timeline Cards & Generation Cells
- Rectangular blocks with `roundedness: 1`. 
- Unprocessed frames remain desaturated with slate wireframes; running tasks show a scanline pulse animation across the cyan border gradient.
- Completed generations display a glass slate footer with resolution tags (`4K`, `24FPS`, `DCI-P3`) in label-sm JetBrains Mono.

### Checkboxes, Toggles & Segmented Selectors
- Checkboxes: 14px squared slate frames with sharp 2px corners; checked states display a solid cyan core with micro-glow.
- Segmented HUD Switchers: Enclosed container in `rgba(7, 11, 20, 0.9)`; active segment illuminates with slate-glass backing (`rgba(30, 41, 59, 0.7)`) and sharp cyan indicator tick marks along the lower edge.

### Specialized Studio Components
- **Cinematic Timecode Scrubber**: Monospaced numerical readout in high-contrast cyan/amber, accented with a 1px vertical neon playhead line cast across timeline tracks.
- **AI Latent Space Node Connector**: Dynamic bezier curves tinted in electric teal (`#14b8a6`) with directional particle glow pulses indicating active prompt token flow.
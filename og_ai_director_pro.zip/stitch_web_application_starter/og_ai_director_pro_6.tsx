import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';
import { 
  Megaphone, Film, User, LayoutGrid, Camera, 
  ChevronLeft, ChevronRight, Menu, X, Plus, 
  Download, Copy, Trash2, Edit2, Loader2, Image as ImageIcon, Settings,
  ArrowRight, ShieldAlert, ShieldCheck, Users, Activity, Key, Mail, Sparkles, Home,
  Clapperboard, Compass, Sliders, Check, RefreshCw, Layers, MonitorPlay, Zap, Eye,
  Rocket, FileText, Route, Play, HelpCircle, BookOpen, MessageSquare, Video
} from 'lucide-react';

import { initializeApp } from 'firebase/app';
import { getAuth, signInWithCustomToken, signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, setDoc, collection, onSnapshot } from 'firebase/firestore';

const AI_CONFIG = {
  TEXT_MODEL: "gemini-3-flash-preview", 
  IMAGE_MODEL: "gemini-3.1-flash-image", 
  API_KEY: "" 
};

const getApiKey = () => {
  if (typeof window !== 'undefined' && window.GOOGLE_API_KEY) {
    return window.GOOGLE_API_KEY;
  }
  return AI_CONFIG.API_KEY;
};

let app, auth, db, appId;
let firebaseReady = false;

try {
  const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : null;
  appId = typeof __app_id !== 'undefined' ? __app_id : 'om-gio-creative-studio';
  
  if (firebaseConfig) {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    firebaseReady = true;
  }
} catch (e) {
  console.warn("Firebase initialize status:", e);
}

const TECH_GRID_SVG = `data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 60 60'%3E%3Cpath d='M60 0 L0 0 0 60' fill='none' stroke='rgba(6,182,212,0.04)' stroke-width='1'/%3E%3Ccircle cx='60' cy='0' r='1' fill='rgba(245,158,11,0.1)'/%3E%3Ccircle cx='0' cy='60' r='1' fill='rgba(6,182,212,0.1)'/%3E%3C/svg%3E`;

const OPTIONS = {
  cameraAngles: [
    "Eye Level", "Low Angle Heroic", "High Angle Dynamic", "Dutch Angle Cinema", "Over-the-Shoulder",
    "Close-Up Emotive", "Extreme Close-Up Macro", "Medium Shot Standard", "Medium Close-Up Portrait", "Full Body Shot Studio", 
    "Bird's Eye View", "Worm's Eye View", "Three-Quarter Editorial", "Profile/Side Silhouette", 
    "POV Smartphone Selfie", "POV First Person Hands", "Mirror Selfie Lifestyle", "Top-Down Flat Lay Minimalist", 
    "Low Angle Streetstyle", "Wide Establishing Architectural", "Two-Shot Dialogue", "Handheld Shaky Raw"
  ],
  affiliateMovements: [
    'Static Locked-Off Master', 'Smooth Pan Kiri-Kanan', 'Tilt Vertikal Dinamis',
    'Dolly In Dramatic', 'Dolly Out Reveal', 'Tracking Follow Shot',
    'Handheld Organic Raw', 'Steadicam Gliding Pro', 'Slow Push-In Climax',
    'Slow Pull-Out Ambient', 'Orbit 360 Cinematic', 'Snap Zoom In Punchy', 
    'Rack Focus Subjek-ke-Produk', 'FPV Drone Sweep', 'Whip Pan Transition'
  ],
  expressions: [
    "Tersenyum Natural & Ramah", "Tersenyum Percaya Diri", "Excited & Sangat Antusias", "Elegan, Tenang & Mewah",
    "Playful & Energik", "Fokus Profesional Serius", "Terkejut Senang / Wow Factor", "Santai Casual Weekend", 
    "Meyakinkan (Persuasive Pitch)", "Mengedip / Charismatic Wink", "Tersipu Manis", 
    "Berpikir Analitis", "Kharismatik Tegas", "Empatik Mendalam", "Terpesona Mengagumi"
  ],
  aspectRatios: ["9:16", "16:9", "3:4", "4:3", "1:1"],
  imageStyles: [
    "Photorealistic Cinema (Sony FX3 35mm f/1.4)", 
    "High-End Fashion Editorial Look", 
    "Commercial Studio Lighting Clean", 
    "Anime Kyotopr Modern Shinkai", 
    "3D Hyper-Render Pixar/Disney 4K", 
    "Cyberpunk Neon Noir 2077", 
    "Warm Vintage Analog 35mm Film", 
    "Minimalist Tech Architectural",
    "Dark Dramatic Chiaroscuro"
  ],
  poses: [
    "Berdiri Tegap Santai", "Menyilangkan Tangan Berwibawa", "Menunjukkan Produk ke Arah Kamera", "Melambai Hangat Menyapa",
    "Duduk Santai di Sofa Lounge", "Selfie Mirror Pose Estetik", "Berpikir dengan Jari di Dagu", "Pose Melangkah Percaya Diri",
    "Menyandarkan Bahu ke Dinding Minimalis", "Memegang Produk Dua Tangan Halus", "POV Tangan Sedang Unboxing", "Tatapan Tajam Misterius Menembus Kamera"
  ]
};

const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    if (file.size > 20 * 1024 * 1024) {
      reject(new Error("Ukuran berkas maksimal 20MB"));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      const mimeType = result.split(';')[0].split(':')[1];
      const data = result.split(',')[1];
      resolve({ mimeType, data, previewUrl: result });
    };
    reader.onerror = error => reject(error);
    reader.readAsDataURL(file);
  });
};

const downloadImage = async (dataUrl, filename) => {
  try {
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.style.display = 'none';
    link.href = blobUrl;
    link.download = filename || `og-ai-director-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    }, 120);
  } catch (err) {
    console.error("Gagal mengunduh gambar:", err);
  }
};

const copyToClipboard = (text) => {
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed'; 
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const success = document.execCommand('copy');
    document.body.removeChild(textarea);
    return success;
  } catch (err) {
    console.error("Gagal menyalin draf:", err);
    return false;
  }
};

const callGeminiText = async (prompt, imageInputs = []) => {
  const apiKey = getApiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${AI_CONFIG.TEXT_MODEL}:generateContent?key=${apiKey}`;
  
  const strictSystemInstruction = "CRITICAL INSTRUCTION: Output directly the requested script, concepts, or JSON without any conversational filler, introductory remarks, greetings, or self-referential titles. Start directly with the content. Ensure 100% strict relevance and absolute adherence to the provided topic/niche.";
  const combinedPrompt = `${strictSystemInstruction}\n\n${prompt}`;

  const parts = [{ text: combinedPrompt }];
  imageInputs.forEach((img) => {
    if (img && img.data) {
      parts.push({
        inlineData: { mimeType: img.mimeType, data: img.data }
      });
    }
  });

  const payload = {
    contents: [{ parts: parts }],
    generationConfig: prompt.includes("JSON_OUTPUT_REQUIRED") ? { responseMimeType: "application/json" } : {}
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) throw new Error(`Gemini Text Error: ${response.status}`);
  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "Maaf, respon teks belum dapat digenerate.";
};

const callGeminiImage = async (prompt, imageInputs = [], aspectRatio = "1:1") => {
  const apiKey = getApiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${AI_CONFIG.IMAGE_MODEL}:generateContent?key=${apiKey}`;
  
  const enhancedPrompt = `${prompt}\n\n[100% LOCKED ABSOLUTE VISUAL INSTRUCTION]: Render this exact prompt composition with uncompromising visual fidelity, exact matching clothing color/outfit style from reference, and absolute adherence to every single detail. Aspect ratio: ${aspectRatio}. Photorealistic textures, calibrated dynamic range, exact visual synchronization with the prompt description.`;
  
  const parts = [{ text: enhancedPrompt }];
  imageInputs.forEach(img => {
    if (img && img.data) {
      parts.push({ inlineData: { mimeType: img.mimeType, data: img.data } });
    }
  });

  const payload = {
    contents: [{ parts: parts }],
    generationConfig: { 
      responseModalities: ["TEXT", "IMAGE"],
      imageConfig: { aspectRatio: aspectRatio }
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) throw new Error(`Gemini Image Error: ${response.status}`);
  const data = await response.json();
  
  const candidateParts = data.candidates?.[0]?.content?.parts || [];
  
  for (const p of candidateParts) {
    if (p.inlineData && p.inlineData.data) {
      return `data:${p.inlineData.mimeType || 'image/png'};base64,${p.inlineData.data}`;
    }
    if (p.fileData && p.fileData.fileUri) {
      return p.fileData.fileUri;
    }
    if (p.text && p.text.startsWith('data:image')) {
      return p.text;
    }
  }

  // Fallback: Check if there is an image in any part object structure
  for (const candidate of (data.candidates || [])) {
    for (const part of (candidate.content?.parts || [])) {
      if (part.inline_data && part.inline_data.data) {
        return `data:${part.inline_data.mime_type || 'image/png'};base64,${part.inline_data.data}`;
      }
    }
  }

  throw new Error("Model belum berhasil mengembalikan representasi visual.");
};

const parseJsonSafe = (rawText, fallbackValue = []) => {
  try {
    let clean = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
    let firstB = clean.indexOf('[');
    let lastB = clean.lastIndexOf(']');
    if (firstB !== -1 && lastB !== -1 && lastB > firstB) {
      clean = clean.substring(firstB, lastB + 1);
    }
    return JSON.parse(clean);
  } catch (err) {
    console.warn("JSON parse fallback triggered:", err);
    return fallbackValue;
  }
};

const ImageUploadSlot = ({ label, onUpload, value, onRemove, compact = false }) => {
  const fileInputRef = useRef(null);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        const base64Data = await fileToBase64(file);
        onUpload(base64Data);
      } catch (err) {
        console.error(err.message);
      }
    }
  };

  const containerHeight = compact ? "min-h-[5.8rem]" : "min-h-[9.5rem]";

  return (
    <div className="bg-[#0e1626]/70 p-3 rounded-2xl border border-cyan-900/40 hover:border-cyan-500/50 transition-all backdrop-blur-md group shadow-lg shadow-black/40">
      <div className={`flex flex-col gap-1.5 w-full h-full ${containerHeight}`}>
        {label && <span className="text-xs text-cyan-200/80 font-bold uppercase tracking-wider">{label}</span>}
        <div 
          className={`relative w-full flex-1 rounded-xl border flex flex-col items-center justify-center cursor-pointer transition-all duration-300 overflow-hidden ${containerHeight}
            ${value ? 'border-cyan-500/80 bg-[#090d16]' : 'border-dashed border-cyan-800/60 hover:border-cyan-400 bg-cyan-950/10 hover:bg-cyan-950/30'}`}
          onClick={() => !value && fileInputRef.current?.click()}
        >
          {value ? (
            <>
              <img src={value.previewUrl} alt="Preview" className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-2">
                <span className="text-[10px] text-cyan-300 font-mono">Tersimpan</span>
                <button 
                  onClick={(e) => { e.stopPropagation(); onRemove(); }}
                  className="p-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-colors shadow-md z-10"
                  title="Hapus gambar"
                >
                  <X size={13} strokeWidth={3} />
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center p-2 text-center">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:scale-110 group-hover:bg-cyan-500/20 transition-all mb-1">
                <ImageIcon size={20} />
              </div>
              <span className="text-[11px] text-gray-400 font-medium tracking-tight">Upload Referensi</span>
              <span className="text-[9px] text-gray-500">JPG/PNG maks 20MB</span>
            </div>
          )}
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
        </div>
      </div>
    </div>
  );
};

const FormGroup = ({ label, children, tip }) => (
  <div className="flex flex-col gap-1.5 mb-4 w-full">
    <div className="flex items-center justify-between">
      <label className="text-xs font-bold text-gray-200 uppercase tracking-wider">{label}</label>
      {tip && <span className="text-[10px] text-cyan-400/80">{tip}</span>}
    </div>
    {children}
  </div>
);

const Input = ({ ...props }) => (
  <input 
    className="w-full bg-[#0a0f1d] border border-cyan-950/80 hover:border-cyan-800 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-cyan-50 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
    {...props}
  />
);

const Select = ({ options, ...props }) => (
  <select 
    className="w-full bg-[#0a0f1d] border border-cyan-950/80 hover:border-cyan-800 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-cyan-50 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-all cursor-pointer"
    {...props}
  >
    {options.map((opt, i) => (
      <option key={i} value={typeof opt === 'string' ? opt : opt.value || opt.label} className="bg-[#0b101e] text-gray-200">
        {typeof opt === 'string' ? opt : opt.label}
      </option>
    ))}
  </select>
);

const Textarea = ({ ...props }) => (
  <textarea 
    className="w-full bg-[#0a0f1d] border border-cyan-950/80 hover:border-cyan-800 focus:border-cyan-400 rounded-xl px-4 py-3 text-sm text-cyan-50 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-all resize-y shadow-inner custom-scrollbar"
    {...props}
  />
);

const Toggle = ({ checked, onChange, label, badge }) => (
  <label className="flex items-center justify-between cursor-pointer p-3 rounded-xl bg-[#0a0f1d]/70 border border-cyan-950 hover:border-cyan-800/60 transition-all">
    <div className="flex items-center gap-2">
      <span className="text-xs font-bold text-gray-200">{label}</span>
      {badge && <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">{badge}</span>}
    </div>
    <div className="relative">
      <input type="checkbox" className="sr-only" checked={checked} onChange={onChange} />
      <div className={`block w-11 h-6 rounded-full transition-colors duration-300 ${checked ? 'bg-gradient-to-r from-cyan-500 to-teal-400' : 'bg-gray-800'}`}></div>
      <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform duration-300 shadow-md ${checked ? 'transform translate-x-5' : ''}`}></div>
    </div>
  </label>
);

const Button = ({ children, variant = 'primary', isLoading, className = '', ...props }) => {
  const baseStyle = "flex items-center justify-center gap-2.5 font-bold text-sm rounded-xl px-6 py-3 transition-all duration-200 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer shadow-lg";
  const variants = {
    primary: "bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-teal-400 text-[#050b14] shadow-cyan-500/20 hover:shadow-cyan-400/40 font-extrabold tracking-wide",
    gold: "bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-[#0f172a] shadow-amber-500/20 font-extrabold",
    secondary: "bg-[#0f172a] text-cyan-200 hover:text-white hover:bg-[#162238] border border-cyan-900/60 hover:border-cyan-500/50",
    danger: "bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20",
    icon: "p-2 bg-[#0d1527] text-gray-300 hover:text-cyan-300 hover:bg-[#131f37] rounded-xl border border-cyan-950"
  };
  
  return (
    <button className={`${baseStyle} ${variants[variant]} ${className}`} disabled={isLoading} {...props}>
      {isLoading ? <Loader2 className="animate-spin" size={18} /> : children}
    </button>
  );
};

const GeneratingOverlay = ({ message = "Direktur AI sedang menyusun visi sinematik..." }) => {
  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#070b14]/95 backdrop-blur-xl w-screen h-screen">
      <div className="relative mb-6">
        <div className="w-24 h-24 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
        <div className="absolute inset-0 flex items-center justify-center">
          <Clapperboard className="text-amber-400 animate-pulse" size={34} />
        </div>
      </div>
      <div className="text-center space-y-2">
        <span className="text-xs uppercase tracking-widest px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-bold">
          OG AI DIRECTOR PRO
        </span>
        <h3 className="text-xl md:text-2xl font-black bg-gradient-to-r from-cyan-400 via-teal-300 to-amber-300 bg-clip-text text-transparent">
          PROSES EKSEKUSI PRODUKSI
        </h3>
        <p className="text-xs md:text-sm text-gray-400 font-medium max-w-sm tracking-wide">
          {message}
        </p>
      </div>
    </div>,
    document.body
  );
};

const GuideModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;
  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in">
      <div className="bg-gradient-to-b from-[#0a0f1d] via-[#070b14] to-[#050811] border border-cyan-500/50 rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-[0_0_60px_rgba(6,182,212,0.2)] overflow-hidden">
        
        {/* Header */}
        <div className="p-6 md:p-7 border-b border-cyan-950 flex items-center justify-between bg-gradient-to-r from-[#060a14] via-[#0b1326] to-[#060a14] shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-teal-500/20 text-cyan-400 border border-cyan-500/40 shadow-inner">
              <BookOpen size={26} className="text-cyan-400 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-extrabold tracking-widest px-3 py-1 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                MASTER STUDIO GUIDE & ALL 8 FEATURES WORKFLOW
              </span>
              <h3 className="text-xl md:text-2xl font-black text-white tracking-wide mt-1.5 font-sans">
                Panduan Lengkap & Visual Alur Kerja Nyata Ke-8 Fitur OG AI Director Pro
              </h3>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-3 text-gray-400 hover:text-white rounded-2xl bg-[#0d1424] border border-cyan-900/80 hover:border-cyan-400 transition-all cursor-pointer shadow-lg"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-8 custom-scrollbar text-xs md:text-sm text-gray-300">
          
          {/* Banner Hero */}
          <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-br from-cyan-950/70 via-[#0d1830]/90 to-teal-950/60 border border-cyan-500/40 shadow-2xl relative overflow-hidden space-y-4">
            <div className="absolute -right-12 -bottom-12 w-56 h-56 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -left-12 -top-12 w-56 h-56 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 font-extrabold text-[11px] border border-amber-500/30">
              <Sparkles size={14} /> SINKRONISASI KONSISTENSI 100% TERKUNCI & PANDUAN KE-8 FITUR UTAMA
            </div>
            
            <h4 className="text-white font-black text-lg md:text-xl leading-snug">
              Studio Orkestrasi Konten, Sutradara, & Pembuatan Prompt Video AI Berstandar Profesional
            </h4>
            
            <p className="text-gray-300 text-xs md:text-sm leading-relaxed max-w-3xl">
              Platform ini dirancang khusus untuk kreator, sutradara, dan pebisnis digital untuk merancang aset visual konsisten, storyboard komposit, hingga naskah per-shot yang siap disalin langsung ke platform video AI terkemuka di dunia.
            </p>
          </div>

          {/* Panduan Visual Alur Kerja Nyata (Diagram Visual Konseptual) */}
          <div className="p-6 md:p-7 rounded-3xl bg-gradient-to-r from-cyan-950/40 via-[#091122]/90 to-blue-950/40 border border-cyan-500/50 space-y-5 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <Compass size={22} className="animate-spin text-cyan-300" style={{ animationDuration: '12s' }} />
              </div>
              <div>
                <h5 className="text-sm md:text-base font-black text-cyan-200 uppercase tracking-wider">
                  🗺️ Peta Alur Visual Nyata (Visual Workflow Direction)
                </h5>
                <p className="text-[11px] text-gray-400">Ikuti arah panah visual di bawah ini untuk memahami bagaimana setiap modul saling terhubung dalam menghasilkan video profesional.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2 text-center">
              <div className="p-4 bg-[#050813] rounded-2xl border border-cyan-900/80 flex flex-col items-center space-y-2 relative shadow-lg">
                <span className="w-7 h-7 rounded-full bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center text-xs border border-cyan-500/40">1</span>
                <span className="text-xs font-bold text-white">Upload Referensi</span>
                <p className="text-[10px] text-gray-400 leading-relaxed">Unggah foto wajah/produk di Character Sheet atau Studio agar AI mengenali objek Anda.</p>
                <div className="hidden md:block absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-cyan-400 font-bold text-base">➔</div>
              </div>

              <div className="p-4 bg-[#050813] rounded-2xl border border-cyan-900/80 flex flex-col items-center space-y-2 relative shadow-lg">
                <span className="w-7 h-7 rounded-full bg-teal-500/20 text-teal-300 font-bold flex items-center justify-center text-xs border border-teal-500/40">2</span>
                <span className="text-xs font-bold text-white">Riset & Rakit Naskah</span>
                <p className="text-[10px] text-gray-400 leading-relaxed">Gunakan Affiliate Prompt, Storyboard Grid, atau AI Generator untuk merancang topik.</p>
                <div className="hidden md:block absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-teal-400 font-bold text-base">➔</div>
              </div>

              <div className="p-4 bg-[#050813] rounded-2xl border border-cyan-900/80 flex flex-col items-center space-y-2 relative shadow-lg">
                <span className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center text-xs border border-amber-500/40">3</span>
                <span className="text-xs font-bold text-white">Render Dokumen & Gambar</span>
                <p className="text-[10px] text-gray-400 leading-relaxed">Sistem merender panel gambar konsisten dan dokumen storyboard komposit utuh.</p>
                <div className="hidden md:block absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-amber-400 font-bold text-base">➔</div>
              </div>

              <div className="p-4 bg-[#050813] rounded-2xl border border-cyan-900/80 flex flex-col items-center space-y-2 shadow-lg">
                <span className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-300 font-bold flex items-center justify-center text-xs border border-emerald-500/40">4</span>
                <span className="text-xs font-bold text-white">Salin & Ekspor Video</span>
                <p className="text-[10px] text-gray-400 leading-relaxed">Salin prompt per-shot ke Kling AI, Runway, atau Google Veo untuk hasil akhir video.</p>
              </div>
            </div>
          </div>

          {/* Eksport ke AI Video External Section */}
          <div className="p-6 md:p-7 rounded-3xl bg-gradient-to-r from-amber-950/30 via-[#10192e]/90 to-cyan-950/40 border border-amber-500/40 space-y-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Rocket size={22} className="animate-bounce" />
              </div>
              <div>
                <h5 className="text-sm md:text-base font-black text-amber-300 uppercase tracking-wider">
                  🚀 Panduan Ekspor Hasil Naskah & Prompt ke AI Video External
                </h5>
                <p className="text-[11px] text-gray-400">Gunakan aset dari studio ini untuk langsung merender video di platform eksternal favorit Anda.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="p-4 bg-[#060a14] rounded-2xl border border-cyan-900/60 space-y-2">
                <span className="text-cyan-400 font-bold block text-xs">1. Salin Master Prompt</span>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Di modul seperti <strong>Storyboard Grid</strong> atau <strong>AI Generator</strong>, klik tombol <strong>"Salin Semua Prompts"</strong> atau salin prompt per shot bahasa Inggris yang telah disediakan.
                </p>
              </div>
              
              <div className="p-4 bg-[#060a14] rounded-2xl border border-cyan-900/60 space-y-2">
                <span className="text-teal-400 font-bold block text-xs">2. Buka Platform Video AI</span>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Buka platform video AI pilihan Anda seperti <strong>Kling AI</strong>, <strong>Runway Gen-3</strong>, <strong>Luma Dream Machine</strong>, atau <strong>Google Veo</strong> di tab browser lain.
                </p>
              </div>
              
              <div className="p-4 bg-[#060a14] rounded-2xl border border-cyan-900/60 space-y-2">
                <span className="text-amber-400 font-bold block text-xs">3. Tempel & Render Video</span>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Tempel (Paste) prompt tersebut ke kolom teks generator video. Jika diperlukan, unggah gambar referensi dari hasil unduhan storyboard ke platform tersebut untuk hasil 100% akurat.
                </p>
              </div>
            </div>
          </div>

          {/* Grid Panduan Ke-8 Fitur Modul Secara Detail */}
          <div className="space-y-4">
            <h5 className="text-xs font-black text-cyan-400 uppercase tracking-widest flex items-center gap-2">
              <Clapperboard size={16} className="text-amber-400" /> 📋 Penjelasan Lengkap Ke-8 Fitur / Modul Studio
            </h5>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><Users size={16}/></div>
                  1. Character Sheet Studio
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Unggah 1 foto referensi untuk merender acuan konsistensi karakter (Portrait Sheet, Close-Up Muka Detail, Full Body Sheet, dan Turnaround Multi-Sudut) berlatar putih bersih dengan baju & wajah terkunci mutlak.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><Camera size={16}/></div>
                  2. Image Studio
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Render thumbnail frame pembuka video (First Frame) atau eksplorasi visual bebas dengan hingga 6 slot referensi gambar estetika dan pilihan gaya seni profesional.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><Megaphone size={16}/></div>
                  3. Affiliate Prompt
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Buat naskah promosi produk & e-commerce konversi tinggi lengkap dengan hook interaktif, sudut kamera pilihan, narasi voice over, dan visual storyboard pendukung terstruktur per-shot.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><User size={16}/></div>
                  4. AI Influencer
                </div>
                <p className="text-xs text-cyan-400 leading-relaxed">
                  Rancang karakter virtual influencer eksklusif (wajah, etnis, gaya rambut, hingga persona) yang otomatis tersimpan ke dalam database studio untuk digunakan di modul lain.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><Film size={16}/></div>
                  5. General Prompt
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Struktur breakdown adegan naratif shot-demi-shot untuk film pendek, video sinematik, atau dokumenter dengan pembagian blok waktu yang presisi.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><LayoutGrid size={16}/></div>
                  6. Storyboard Grid
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Rakit panel storyboard multi-adegan ke dalam dokumen komposit utuh lengkap dengan naskah per-shot, dialog otomatis, dan tombol salin prompt konsisten.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><Route size={16}/></div>
                  7. AI Generator (Master Pipeline)
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Jalur produksi terpadu end-to-end dari riset 10 ide konten, naskah, hingga render visual storyboard komposit siap unduh.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/70 hover:border-cyan-500/50 transition-all space-y-2.5 shadow-lg">
                <div className="flex items-center gap-2.5 text-cyan-300 font-bold text-sm">
                  <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400"><Users size={16}/></div>
                  8. Generative AI (AI Gen)
                </div>
                <p className="text-xs text-cyan-300 leading-relaxed">
                  Spesial dialog & aksi multi-karakter konsisten dengan pilihan durasi fleksibel hingga beberapa menit serta lembar dokumen storyboard komposit siap pakai.
                </p>
              </div>

            </div>
          </div>

          {/* Langkah Penggunaan Cepat */}
          <div className="p-6 md:p-7 rounded-3xl bg-gradient-to-r from-cyan-950/50 to-teal-950/40 border border-cyan-800/60 space-y-4 shadow-xl">
            <h5 className="text-xs font-black text-amber-400 uppercase tracking-widest flex items-center gap-2">
              <Zap size={16} /> 💡 3 Langkah Mudah Menghasilkan Konten Pro
            </h5>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div className="p-4 bg-[#070b14]/90 rounded-2xl border border-cyan-900/60 space-y-1.5">
                <span className="text-cyan-400 font-bold block text-xs">1. Unggah Referensi</span>
                <p className="text-[11px] text-gray-400 leading-relaxed">Masukkan foto karakter atau produk Anda agar AI mengenali subjek dengan akurat.</p>
              </div>
              <div className="p-4 bg-[#070b14]/90 rounded-2xl border border-cyan-900/60 space-y-1.5">
                <span className="text-teal-400 font-bold block text-xs">2. Atur Parameter & Topik</span>
                <p className="text-[11px] text-gray-400 leading-relaxed">Pilih jenis format, durasi, sudut kamera, dan ketik topik spesifik Anda.</p>
              </div>
              <div className="p-4 bg-[#070b14]/90 rounded-2xl border border-cyan-900/60 space-y-1.5">
                <span className="text-amber-400 font-bold block text-xs">3. Eksekusi & Ekspor</span>
                <p className="text-[11px] text-gray-400 leading-relaxed">Klik Generate untuk mendapatkan hasil naskah, gambar storyboard, dan prompt siap salin.</p>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-5 border-t border-cyan-950 bg-[#060a14] flex justify-end shrink-0">
          <Button onClick={onClose} className="!py-3 !px-10 text-xs font-extrabold shadow-lg">
            Saya Paham & Siap Berkarya
          </Button>
        </div>

      </div>
    </div>,
    document.body
  );
};

const WorkspaceHome = ({ TABS, setActiveTab }) => {
  const [guideOpen, setGuideOpen] = useState(false);

  return (
    <div className="flex flex-col items-center justify-center py-6 px-2 max-w-5xl mx-auto space-y-10 animate-in fade-in">
      <GuideModal isOpen={guideOpen} onClose={() => setGuideOpen(false)} />

      <div className="text-center space-y-4 relative">
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-bold tracking-wider shadow-inner">
          <Zap size={14} className="text-amber-400" />
          NEXT-GEN AI PRODUCTION ENVIRONMENT
        </div>
        
        <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-white leading-tight font-sans">
          OG AI <span className="bg-gradient-to-r from-cyan-400 via-teal-400 to-amber-300 bg-clip-text text-transparent">DIRECTOR PRO</span>
        </h1>
        
        <p className="text-gray-400 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
          Studio orkestrasi konten dan sutradara kecerdasan buatan terlengkap. Rancang naskah video afiliasi konversi tinggi, prompt film pendek sinematik, visual frame pembuka, model influencer virtual, hingga storyboard grid utuh dengan sinkronisasi 100% terkunci.
        </p>
      </div>

      <div className="w-full p-6 rounded-3xl bg-gradient-to-r from-cyan-950/40 via-[#0d1627]/60 to-amber-950/20 border border-cyan-800/40 backdrop-blur-md text-center shadow-2xl relative overflow-hidden flex flex-col items-center space-y-4">
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center justify-center gap-2 text-cyan-400 font-extrabold text-sm tracking-wider uppercase">
          <Clapperboard size={18} className="text-amber-400" /> 
          Pusat Kontrol Produksi Siap Pakai
        </div>
        <p className="text-xs sm:text-sm text-gray-300 max-w-lg mx-auto">
          Pilih modul di bawah ini atau gunakan sidebar navigasi di sebelah kiri untuk mulai menghasilkan aset konten komersial berkualitas studio.
        </p>
        
        <button 
          onClick={() => setGuideOpen(true)}
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-[#0f172a] font-extrabold text-xs shadow-lg shadow-amber-500/20 hover:scale-105 transition-all cursor-pointer"
        >
          <HelpCircle size={16} /> CARA PAKAI FITUR WEB INI (PANDUAN)
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 w-full">
        {TABS.filter(t => t.id !== 'home' && t.id !== 'admin').map((tab) => {
          const Icon = tab.icon;
          return (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="p-6 rounded-2xl border border-cyan-900/40 bg-[#0d1424]/70 hover:bg-[#121c32]/80 hover:border-cyan-400/70 transition-all duration-300 text-left flex flex-col justify-between group backdrop-blur-md shadow-xl hover:shadow-cyan-500/10 relative overflow-hidden cursor-pointer"
            >
              <div className="flex items-center justify-between mb-4 w-full">
                <div className="p-3.5 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-500/20 group-hover:text-cyan-300 transition-all border border-cyan-500/20">
                  <Icon size={24} />
                </div>
                <ArrowRight size={18} className="text-gray-600 group-hover:text-amber-400 group-hover:translate-x-1 transition-all" />
              </div>
              <div className="space-y-1">
                <span className="text-[11px] text-cyan-400 font-bold uppercase tracking-wider block font-mono">{tab.subtitle}</span>
                <h4 className="font-extrabold text-lg text-white group-hover:text-cyan-200 transition-colors">{tab.title}</h4>
                <p className="text-xs text-gray-400 pt-1 line-clamp-2">{tab.desc}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

const CharacterSheetStudio = () => {
  const [refImage, setRefImage] = useState(null);
  const [characterName, setCharacterName] = useState('');
  const [style, setStyle] = useState(OPTIONS.imageStyles[0]);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [sheets, setSheets] = useState({
    portrait: null,
    closeup: null,
    fullBody: null,
    turnaround: null
  });

  const handleGenerateSheets = async () => {
    if (!refImage) return;
    setLoading(true);
    setSheets({ portrait: null, closeup: null, fullBody: null, turnaround: null });

    try {
      const charTag = characterName.trim() ? `character named "${characterName.trim()}"` : "the character";

      setLoadingMsg("Merender Character Portrait Sheet berlatar putih bersih dengan pakaian & muka yang konsisten 100%...");
      const portraitPrompt = `100% LOCKED CHARACTER PORTRAIT SHEET: Create a professional character headshot and facial expression emotion sheet for ${charTag} based strictly on the provided reference image. Absolute uncompromising consistency: match exact face, facial features, exact eye shape, nose, hairstyle, and exact outfit (matching color, fabric, and style) from reference photo. Artistic style: ${style}. Multiple head angles showing detailed facial features and clean expressions. SOLID PURE WHITE BACKGROUND (#FFFFFF), studio lighting, high resolution.`;
      const portraitImg = await callGeminiImage(portraitPrompt, [refImage], "1:1");
      setSheets(prev => ({ ...prev, portrait: portraitImg }));

      setLoadingMsg("Merender Close-Up Facial Portrait berlatar putih bersih dengan wajah & baju identik...");
      const closeupPrompt = `100% LOCKED CLOSE-UP FACIAL PORTRAIT: Create a high-detail close-up facial portrait framing for ${charTag} based strictly on the provided reference image. Absolute uncompromising consistency: exact identical face, exact facial features, eyes, nose, lips, hair, and exact identical clothing style/color from reference photo. Artistic style: ${style}. Sharp facial focus, expressive eyes. SOLID PURE WHITE BACKGROUND (#FFFFFF), studio portrait lighting, 8k resolution.`;
      const closeupImg = await callGeminiImage(closeupPrompt, [refImage], "1:1");
      setSheets(prev => ({ ...prev, closeup: closeupImg }));

      setLoadingMsg("Merender Full Body Character Reference Sheet berlatar putih bersih...");
      const fullBodyPrompt = `100% LOCKED FULL BODY REFERENCE SHEET: Create a complete full body character reference sheet for ${charTag} based strictly on the provided reference image. Absolute uncompromising consistency: exact face, facial features, hair, and exact identical clothing color/style from reference photo. Artistic style: ${style}. Full standing pose displaying full outfit and distinct proportions. SOLID PURE WHITE BACKGROUND (#FFFFFF), professional studio character design sheet layout, 8k resolution.`;
      const fullBodyImg = await callGeminiImage(fullBodyPrompt, [refImage], "3:4");
      setSheets(prev => ({ ...prev, fullBody: fullBodyImg }));

      setLoadingMsg("Merender Multi-View Character Sheet / Turnaround berlatar putih bersih...");
      const turnaroundPrompt = `100% LOCKED MULTI-VIEW CHARACTER TURNAROUND: Create a professional multi-view character turnaround sheet showing front view, 3/4 view, side profile view, and back view for ${charTag} based strictly on the provided reference image. Absolute uncompromising consistency: exact face, facial features, hair, and exact identical clothing color/style from reference photo. Artistic style: ${style}. SOLID PURE WHITE BACKGROUND (#FFFFFF), technical character model sheet, exact consistent proportions across all angles.`;
      const turnaroundImg = await callGeminiImage(turnaroundPrompt, [refImage], "16:9");
      setSheets(prev => ({ ...prev, turnaround: turnaroundImg }));

    } catch (err) {
      console.error("Character Sheet generation error:", err);
    } finally {
      setLoading(false);
      setLoadingMsg('');
    }
  };

  return (
    <div className="space-y-8 animate-in max-w-5xl mx-auto">
      {loading && <GeneratingOverlay message={loadingMsg || "Memproses aset Character Sheet konsistensi tinggi secara bersamaan..."} />}

      <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-6">
        <div className="flex items-center gap-3 border-b border-cyan-950 pb-4">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Users size={22} />
          </div>
          <div>
            <h3 className="text-base font-black text-cyan-200 uppercase tracking-wider">Character Sheet Studio (Konsistensi Video 100%)</h3>
            <p className="text-xs text-gray-400">Unggah 1 foto referensi untuk menghasilkan acuan konsistensi karakter (termasuk close-up wajah & baju sama persis) berlatar putih bersih secara instan.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <span className="text-xs font-bold text-gray-300 block mb-2 uppercase tracking-wider">Foto Referensi Utama (Wajib)</span>
            <ImageUploadSlot label="" value={refImage} onUpload={setRefImage} onRemove={() => setRefImage(null)} compact={false} />
          </div>

          <div className="space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <FormGroup label="Nama Karakter (Opsional)">
                <Input placeholder="Contoh: Alex, Maya, Detektif Budi" value={characterName} onChange={e => setCharacterName(e.target.value)} />
              </FormGroup>

              <FormGroup label="Gaya Visual / Seni">
                <Select options={OPTIONS.imageStyles} value={style} onChange={e => setStyle(e.target.value)} />
              </FormGroup>
            </div>

            <Button onClick={handleGenerateSheets} isLoading={loading} disabled={!refImage} className="w-full !py-3.5 !bg-gradient-to-r !from-emerald-600 !to-teal-500">
              <Sparkles size={18} /> GENERATE CHARACTER SHEETS (LATAR PUTIH)
            </Button>
          </div>
        </div>
      </div>

      {(sheets.portrait || sheets.closeup || sheets.fullBody || sheets.turnaround) && (
        <div className="space-y-6 animate-in zoom-in">
          <div className="p-5 rounded-3xl bg-[#0a0f1d] border border-emerald-800/60 shadow-2xl space-y-6">
            <div className="flex justify-between items-center border-b border-emerald-950 pb-3">
              <h4 className="text-sm font-black text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <Check size={18} /> Hasil Character Sheets Konsistensi Siap Pakai (Terkunci Baju & Muka)
              </h4>
              <span className="text-[10px] px-2.5 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">Background: Solid Pure White (#FFFFFF)</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {sheets.portrait && (
                <div className="p-4 rounded-2xl bg-[#060a14] border border-cyan-900/60 flex flex-col justify-between space-y-3 shadow-xl">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-amber-400 block uppercase">1. Portrait Sheet</span>
                    <p className="text-[10px] text-gray-400">Ekspresi wajah & sudut pandang</p>
                  </div>
                  <div className="aspect-square rounded-xl overflow-hidden bg-white border border-cyan-950 flex items-center justify-center p-1">
                    <img src={sheets.portrait} alt="Portrait Sheet" className="w-full h-full object-contain" />
                  </div>
                  <Button onClick={() => downloadImage(sheets.portrait, `${characterName || 'character'}-portrait-sheet.png`)} variant="secondary" className="w-full !py-2 text-xs">
                    <Download size={14} /> Unduh Portrait (PNG)
                  </Button>
                </div>
              )}

              {sheets.closeup && (
                <div className="p-4 rounded-2xl bg-[#060a14] border border-cyan-900/60 flex flex-col justify-between space-y-3 shadow-xl">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-teal-400 block uppercase">2. Close-Up Wajah</span>
                    <p className="text-[10px] text-gray-400">Fokus muka detail tajam</p>
                  </div>
                  <div className="aspect-square rounded-xl overflow-hidden bg-white border border-cyan-950 flex items-center justify-center p-1">
                    <img src={sheets.closeup} alt="CloseUp Sheet" className="w-full h-full object-contain" />
                  </div>
                  <Button onClick={() => downloadImage(sheets.closeup, `${characterName || 'character'}-closeup-face.png`)} variant="secondary" className="w-full !py-2 text-xs">
                    <Download size={14} /> Unduh Close-Up (PNG)
                  </Button>
                </div>
              )}

              {sheets.fullBody && (
                <div className="p-4 rounded-2xl bg-[#060a14] border border-cyan-900/60 flex flex-col justify-between space-y-3 shadow-xl">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-cyan-400 block uppercase">3. Full Body Sheet</span>
                    <p className="text-[10px] text-gray-400">Proporsi tubuh penuh & outfit</p>
                  </div>
                  <div className="aspect-[3/4] rounded-xl overflow-hidden bg-white border border-cyan-950 flex items-center justify-center p-1">
                    <img src={sheets.fullBody} alt="Full Body Sheet" className="w-full h-full object-contain" />
                  </div>
                  <Button onClick={() => downloadImage(sheets.fullBody, `${characterName || 'character'}-fullbody-sheet.png`)} variant="secondary" className="w-full !py-2 text-xs">
                    <Download size={14} /> Unduh Full Body (PNG)
                  </Button>
                </div>
              )}

              {sheets.turnaround && (
                <div className="p-4 rounded-2xl bg-[#060a14] border border-cyan-900/60 flex flex-col justify-between space-y-3 shadow-xl">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-emerald-400 block uppercase">4. Turnaround Sheet</span>
                    <p className="text-[10px] text-gray-400">Tampak depan, sisi & belakang</p>
                  </div>
                  <div className="aspect-video rounded-xl overflow-hidden bg-white border border-cyan-950 flex items-center justify-center p-1">
                    <img src={sheets.turnaround} alt="Turnaround Sheet" className="w-full h-full object-contain" />
                  </div>
                  <Button onClick={() => downloadImage(sheets.turnaround, `${characterName || 'character'}-turnaround-sheet.png`)} variant="secondary" className="w-full !py-2 text-xs">
                    <Download size={14} /> Unduh Turnaround (PNG)
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const MultiCharacterNarrativeStudio = ({ savedCharacters }) => {
  const [step, setStep] = useState(1);
  const [inputMode, setInputMode] = useState('auto'); // 'auto' | 'manual'
  const [characters, setCharacters] = useState([
    { id: 1, name: 'Karakter 1 (Utama)', role: 'Protagonis / Host Utama', refImage: null },
    { id: 2, name: 'Karakter 2 (Pendukung)', role: 'Antagonis / Narasumber / Co-Host', refImage: null }
  ]);
  const [formData, setFormData] = useState({
    category: 'Film Pendek Laga / Action',
    genre: 'Drama Aksi & Ketegangan',
    tone: 'Sinematik & Dramatis',
    premise: '',
    cameraMotion: 'Dynamic Steadicam Follow',
    style: OPTIONS.imageStyles[0],
    videoEngine: 'Kling AI / Google Veo (Dense Action)',
    aspectRatio: '16:9',
    duration: '30 Detik'
  });
  const [ideasList, setIdeasList] = useState([]);
  const [selectedIdea, setSelectedIdea] = useState(null);
  
  const [scriptAndRenderResult, setScriptAndRenderResult] = useState({
    script: '',
    shots: [],
    compositeUrl: null
  });

  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedPrompts, setCopiedPrompts] = useState(false);
  const [copiedShotIndex, setCopiedShotIndex] = useState(null);

  const addCharacterSlot = () => {
    if (characters.length >= 4) return;
    setCharacters(prev => [
      ...prev,
      { id: prev.length + 1, name: `Karakter ${prev.length + 1}`, role: 'Karakter Pendukung', refImage: null }
    ]);
  };

  const updateCharacter = (idx, field, val) => {
    const next = [...characters];
    next[idx][field] = val;
    setCharacters(next);
  };

  const handleGenerateIdeas = async () => {
    if (inputMode === 'manual') {
      if (!formData.premise.trim()) return;
      setSelectedIdea({
        title: formData.premise,
        conflict: `Konflik terarah khusus topik: ${formData.premise}`,
        hook: `Hook pembuka yang memukau mengenai ${formData.premise}`,
        plot: `Alur cerita komprehensif yang membahas secara tuntas dan konsisten topik: ${formData.premise}`
      });
      setStep(3);
      return;
    }

    setLoading(true);
    setLoadingMsg("Menganalisis topik dan merumuskan tepat 5 pilihan ide cerita multi-karakter yang SANGAT RELEVAN...");
    try {
      const prompt = `JSON_OUTPUT_REQUIRED
Sebagai sutradara film dan serial profesional, buatkan tepat 5 pilihan ide cerita / topik konten yang SANGAT RELEVAN dan WAJIB BERFOKUS KETAT dan KONSISTEN pada topik/kategori: "${formData.category}", Genre: "${formData.genre}".
${formData.premise ? `Kata Kunci / Premis Spesifik Pengguna: "${formData.premise}". Wajib jadikan topik/premise ini inti utama dari ke-5 ide cerita dan jangan menyimpang sedikit pun dari topik ini.` : 'Buatkan ide cerita multi-karakter yang sangat menarik dan sesuai persis dengan kategori tersebut.'}
Karakter Terlibat: ${characters.map(c => `${c.name} (${c.role})`).join(', ')}.

Output WAJIB format JSON ARRAY murni tanpa backtick berisi tepat 5 objek:
[
  {
    "title": "Judul Cerita / Topik",
    "conflict": "Konflik atau interaksi antar karakter",
    "hook": "Hook pembuka adegan pertama",
    "plot": "Alur cerita singkat dari awal sampai akhir"
  }
]`.trim();

      const res = await callGeminiText(prompt);
      let parsed = parseJsonSafe(res, [
        { title: `${formData.category}: Konflik Utama`, conflict: "Pertemuan rahasia dua kubu", hook: "Langkah tergesa di lorong gelap", plot: "Awal pertempuran psikologis." },
        { title: `${formData.category}: Dialog Kritis`, conflict: "Perdebatan arah kebijakan", hook: "Gebrakan meja penuh ketegangan", plot: "Pencarian solusi lintas batas." },
        { title: `${formData.category}: Misi Darurat`, conflict: "Waktu menipis menyelamatkan sandera", hook: "Detik jam dinding berdetak keras", plot: "Aksi kejar-kejaran dramatis." },
        { title: `${formData.category}: Aliansi Baru`, conflict: "Musuh lama bersatu", hook: "Tatapan mata penuh curiga", plot: "Kerjasama rahasia membongkar sindikat." },
        { title: `${formData.category}: Klimaks Aksi`, conflict: "Duel penentu nasib", hook: "Kilatan cahaya senjata pemungkas", plot: "Klimaks penuh emosi dan ketegangan." }
      ]);
      setIdeasList(parsed);
      setStep(2);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectIdea = (idea) => {
    setSelectedIdea(idea);
    setStep(3);
  };

  const handleExecuteFullProduction = async () => {
    setLoading(true);
    setLoadingMsg("Menyusun naskah dialog interaktif padat 10 detik per shot, merender prompt AI video & storyboard komposit (100% terkunci sinkron dan konsisten pakaian baju)...");
    try {
      const scriptPrompt = `Sebagai Head Writer, buatkan naskah lengkap multi-karakter yang SANGAT RELEVAN dan berfokus tajam pada:
Cerita: ${selectedIdea?.title}
Konflik: ${selectedIdea?.conflict}
Kategori & Genre: ${formData.category} / ${formData.genre}
Karakter: ${characters.map(c => `${c.name} (${c.role})`).join(', ')}.
Durasi Total Target: ${formData.duration}.
PENTING: WAJIB pecah menjadi per-shot dengan durasi TEPAT 10 DETIK padat isi isinya (Gunakan format tag wajib: [SHOT 01 | 00:00 - 00:10], [SHOT 02 | 00:10 - 00:20], dst).
[CRITICAL 100% WARDROBE & OUTFIT COLOR & FACE CONSISTENCY LOCK]: Every single shot must explicitly maintain the exact same character wardrobe, clothing style, colors, outfit details, and facial appearance across the entire script without any variation.

Format per shot:
[SHOT 01 | 00:00 - 00:10]
- Visual / Aksi: ...
- Dialog / Interaksi Karakter: ...
- Emosi & Ekspresi: ...
`.trim();

      const scriptRes = await callGeminiText(scriptPrompt);

      const imageInputs = [];
      characters.forEach(c => {
        if (c.refImage) imageInputs.push(c.refImage);
      });

      const promptEngineerPrompt = `JSON_OUTPUT_REQUIRED
As a Master Prompt Engineer, create exact AI video prompts in English for each 10-second shot based strictly on this script:
${scriptRes}

[ABSOLUTE 100% WARDROBE, OUTFIT COLOR & FACE LOCK]: Every single prompt MUST explicitly clone the exact clothing style, exact outfit colors, fabric, and facial features from the reference images. DO NOT alter the outfit, colors, or appearance across shots.

Output JSON ARRAY pure without backticks:
[
  {
    "id": 1,
    "timeRange": "00:00 - 00:10",
    "action": "Multi-character action description with locked wardrobe and consistent appearance",
    "prompt": "English cinematic video prompt maintaining 100% strict consistent character wardrobe, outfit colors, and strict topic '${selectedIdea?.title}'..."
  }
]`.trim();

      const promptsRes = await callGeminiText(promptEngineerPrompt, imageInputs);
      let parsedShots = parseJsonSafe(promptsRes, [
        { id: 1, timeRange: "00:00 - 00:10", action: "Opening sequence with characters interacting.", prompt: `Cinematic shot of multiple characters in conversation with 100% locked wardrobe and consistent clothing for topic ${selectedIdea?.title}, dramatic lighting, 8k` }
      ]);

      const rendered = [];
      for (let i = 0; i < parsedShots.length; i++) {
        setLoadingMsg(`Merender visual shot ${i + 1} dari ${parsedShots.length} (Kunci Konsistensi Baju & Wajah 100% Tersinkron)...`);
        try {
          const lockedVisualPrompt = `[ABSOLUTE 100% WARDROBE, OUTFIT COLOR & FACE LOCK]: Render the EXACT visual prompt verbatim with uncompromising consistency in clothing style, outfit colors, and character features: "${parsedShots[i].prompt}". Strict topic context: "${selectedIdea?.title || formData.category}". Visual style: "${formData.style}", aspect ratio ${formData.aspectRatio}, 8k photorealistic resolution, perfectly matched details.`;
          const img = await callGeminiImage(lockedVisualPrompt, imageInputs, formData.aspectRatio);
          rendered.push({ ...parsedShots[i], img });
        } catch (e) {
          rendered.push({ ...parsedShots[i], img: null });
        }
      }

      setLoadingMsg("Menyusun dokumen storyboard komposit...");
      const valid = rendered.filter(s => s.img);
      let composite = null;

      if (valid.length > 0) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const cols = 2;
        const rows = Math.ceil(valid.length / cols);
        const cw = 720;
        const ch = formData.aspectRatio === '9:16' ? 1280 : formData.aspectRatio === '1:1' ? 720 : 405;
        const th = 340, pad = 40, hh = 140;

        canvas.width = cols * cw + (cols + 1) * pad;
        canvas.height = hh + rows * (ch + th) + (rows + 1) * pad;

        ctx.fillStyle = '#060a14';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#0e172a';
        ctx.fillRect(pad, pad, canvas.width - (pad * 2), hh - pad);
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 2;
        ctx.strokeRect(pad, pad, canvas.width - (pad * 2), hh - pad);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 32px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText('STORYBOARD PRODUCTION DOCUMENT (100% WARDROBE & FACE LOCKED)', pad + 40, pad + 55);

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText(`Topik: ${selectedIdea?.title || formData.category} | Rasio: ${formData.aspectRatio}`, pad + 40, pad + 95);

        const wrapText = (text, startX, startY, maxWidth, lineHeight, fontStyle, color) => {
            ctx.fillStyle = color;
            ctx.font = fontStyle;
            const words = text.split(' ');
            let line = '';
            for(let n = 0; n < words.length; n++) {
                let testLine = line + words[n] + ' ';
                if (ctx.measureText(testLine).width > maxWidth && n > 0) {
                    ctx.fillText(line, startX, startY);
                    line = words[n] + ' ';
                    startY += lineHeight;
                } else {
                    line = testLine;
                }
            }
            ctx.fillText(line, startX, startY);
            return startY + lineHeight;
        };

        for (let i = 0; i < valid.length; i++) {
          const item = valid[i];
          const col = i % cols;
          const row = Math.floor(i / cols);
          const x = pad + col * (cw + pad);
          const y = hh + pad + row * (ch + th + pad);

          const imgEl = new Image();
          await new Promise((res) => { imgEl.onload = res; imgEl.onerror = res; imgEl.src = item.img; });

          ctx.drawImage(imgEl, x, y, cw, ch);

          ctx.fillStyle = '#0f172a';
          ctx.fillRect(x, y + ch, cw, th);

          ctx.fillStyle = '#1e293b';
          ctx.fillRect(x, y + ch, cw, 45);

          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 3;
          ctx.strokeRect(x, y, cw, ch + th);

          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(x, y + ch);
          ctx.lineTo(x + cw, y + ch);
          ctx.stroke();

          ctx.fillStyle = '#f59e0b';
          ctx.font = 'bold 20px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText(`SHOT 0${item.id}`, x + 25, y + ch + 30);

          ctx.fillStyle = '#94a3b8';
          ctx.font = 'bold 16px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText(`[ ${item.timeRange || 'Adegan'} ]`, x + 130, y + ch + 29);

          let currentY = y + ch + 85;

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText('AKSI:', x + 25, currentY);
          currentY = wrapText(item.action, x + 85, currentY, cw - 110, 24, '18px "Segoe UI", Roboto, Helvetica, sans-serif', '#e2e8f0') + 15;

          ctx.fillStyle = '#94a3b8';
          ctx.font = 'bold 16px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText('PROMPT:', x + 25, currentY);
          wrapText(item.prompt, x + 105, currentY, cw - 130, 22, '16px "Segoe UI", Roboto, Helvetica, sans-serif', '#94a3b8');
        }
        composite = canvas.toDataURL('image/png');
      }

      setScriptAndRenderResult({
        script: scriptRes,
        shots: rendered,
        compositeUrl: composite
      });
      setStep(4);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyCombinedShotCard = (shotItem, shotBlockText, idx) => {
    const combinedCardText = `=== SHOT ${shotItem.id} (${shotItem.timeRange || '10 Detik'}) ===\n\n[NASKAH & DIALOG/AKSI]:\n${shotBlockText.trim()}\n\n[MASTER AI VIDEO PROMPT]:\n${shotItem.prompt}`;
    if (copyToClipboard(combinedCardText)) {
      setCopiedShotIndex(idx);
      setTimeout(() => setCopiedShotIndex(null), 2000);
    }
  };

  const copyAllPrompts = () => {
    const text = scriptAndRenderResult.shots.map(s => `SHOT ${s.id} (${s.timeRange}):\n${s.prompt}\n`).join('\n');
    if (copyToClipboard(text)) {
      setCopiedPrompts(true);
      setTimeout(() => setCopiedPrompts(false), 2000);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in max-w-5xl mx-auto">
      {loading && <GeneratingOverlay message={loadingMsg} />}

      <div className="flex items-center justify-between relative mb-8">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-cyan-950 -z-10 rounded-full"></div>
        <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-emerald-500 -z-10 rounded-full transition-all duration-500" style={{ width: `${(step - 1) * 33.33}%` }}></div>
        
        {[
          { num: 1, label: "Karakter & Topik" },
          { num: 2, label: "Pilih / Input Topik" },
          { num: 3, label: "Konfirmasi Ide" },
          { num: 4, label: "Produksi Selesai" }
        ].map((s) => (
          <div key={s.num} className="flex flex-col items-center gap-2 bg-[#070b14] px-2">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 font-bold text-xs
              ${step >= s.num ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-[#0a0f1d] border-cyan-900/50 text-gray-500'}
              ${step === s.num ? 'shadow-[0_0_15px_rgba(16,185,129,0.4)] scale-110' : ''}
            `}>
              {s.num}
            </div>
            <span className={`text-[10px] uppercase font-bold ${step >= s.num ? 'text-emerald-400' : 'text-gray-500'}`}>{s.label}</span>
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-6 animate-in slide-in-from-right-4">
          <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-5">
            <div className="flex items-center justify-between border-b border-cyan-950 pb-3">
              <div className="flex items-center gap-2">
                <Users size={18} className="text-cyan-400" />
                <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Pengaturan Multi-Karakter Konsisten</h3>
              </div>
              <Button variant="secondary" onClick={addCharacterSlot} className="!py-1.5 !px-3 text-xs">
                <Plus size={14} /> Tambah Karakter
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {characters.map((char, idx) => (
                <div key={char.id} className="p-4 rounded-2xl bg-[#060a14] border border-cyan-950 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-amber-400 font-mono">Karakter #{char.id}</span>
                    {characters.length > 2 && (
                      <button onClick={() => setCharacters(characters.filter((_, i) => i !== idx))} className="text-gray-500 hover:text-rose-400">
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                  <Input placeholder="Nama Karakter (Cth: Alex / Detektif Budi)" value={char.name} onChange={e => updateCharacter(idx, 'name', e.target.value)} />
                  <Input placeholder="Peran (Cth: Protagonis / Narasumber 1)" value={char.role} onChange={e => updateCharacter(idx, 'role', e.target.value)} />
                  <div>
                    <span className="text-[10px] text-gray-400 block mb-1">Unggah Wajah Konsisten:</span>
                    <ImageUploadSlot compact={true} label="" value={char.refImage} onUpload={d => updateCharacter(idx, 'refImage', d)} onRemove={() => updateCharacter(idx, 'refImage', null)} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-4">
            <div className="flex items-center justify-between border-b border-cyan-950 pb-3">
              <div className="flex items-center gap-2">
                <Clapperboard size={18} className="text-amber-400" />
                <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Kategori & Topik Spesifik</h3>
              </div>
              <div className="flex gap-1.5 bg-[#050914] p-1 rounded-xl border border-cyan-950">
                <button 
                  onClick={() => setInputMode('auto')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${inputMode === 'auto' ? 'bg-cyan-500 text-[#050b14]' : 'text-gray-400 hover:text-white'}`}
                >
                  Riset Ide Otomatis
                </button>
                <button 
                  onClick={() => setInputMode('manual')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${inputMode === 'manual' ? 'bg-cyan-500 text-[#050b14]' : 'text-gray-400 hover:text-white'}`}
                >
                  Input Topik Manual
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormGroup label="Kategori Konten">
                <Select options={[
                  'Film Pendek Laga / Action', 
                  'Podcast Interaktif 2+ Orang', 
                  'Drama Serial Percakapan', 
                  'Video Investigasi / Dokumenter', 
                  'Komedi / Sketsa Multi-Karakter',
                  'Full Animasi 3D (Pixar / Disney Style)',
                  'Full Animasi 2D / Anime Style'
                ]} value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} />
              </FormGroup>
              <FormGroup label="Genre / Kategori Cerita">
                <Select options={[
                  'Full Animasi 3D (Pixar / Disney Style)', 
                  'Full Animasi 2D / Anime Style', 
                  'Drama Aksi & Ketegangan', 
                  'Misteri / Thriller', 
                  'Komedi Santai', 
                  'Edukasi / Diskusi Mendalam', 
                  'Sci-Fi & Fantasi'
                ]} value={formData.genre} onChange={e => setFormData({...formData, genre: e.target.value})} />
              </FormGroup>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormGroup label="Aspek Rasio Frame">
                <Select options={OPTIONS.aspectRatios} value={formData.aspectRatio} onChange={e => setFormData({...formData, aspectRatio: e.target.value})} />
              </FormGroup>
              <FormGroup label="Durasi Total Target">
                <Select options={['10 Detik', '20 Detik', '30 Detik', '40 Detik', '50 Detik', '60 Detik / 1 Menit', '2 Menit', '3 Menit', '4 Menit', '5 Menit']} value={formData.duration} onChange={e => setFormData({...formData, duration: e.target.value})} />
              </FormGroup>
            </div>

            <FormGroup label={inputMode === 'manual' ? "Ketik Topik / Skenario / Cerita Animasi Anda Secara Manual (Wajib)" : "Topik Spesifik / Premis Cerita / Ide (Wajib Diisi Agar Relevan)"} tip={inputMode === 'manual' ? "Topik akan langsung diproses tanpa riset otomatis" : "Contoh: Pertemuan rahasia agen rahasia di kafe malam hari"}>
              <Textarea placeholder={inputMode === 'manual' ? "Tuliskan topik atau skenario persis yang ingin Anda buat..." : "Pertemuan rahasia agen rahasia di kafe malam hari"} value={formData.premise} onChange={e => setFormData({...formData, premise: e.target.value})} rows={3} />
            </FormGroup>

            <Button onClick={handleGenerateIdeas} isLoading={loading} className="w-full !bg-gradient-to-r !from-emerald-600 !to-teal-500">
              {inputMode === 'manual' ? "Gunakan Topik Ini & Lanjut Konfirmasi <ArrowRight size={16} />" : "Riset & Munculkan 5 Pilihan Ide Sesuai Topik <ArrowRight size={16} />"}
            </Button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4 animate-in slide-in-from-right-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-black text-amber-300 uppercase tracking-wider">Pilih 1 dari 5 Topik & Ide Cerita Sesuai Topik Anda</h3>
            <Button variant="secondary" onClick={() => setStep(1)} className="!py-1.5 !px-3 text-xs">Kembali</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ideasList.map((idea, idx) => (
              <div key={idx} className="bg-[#060a14] border border-cyan-900/60 rounded-2xl p-5 flex flex-col justify-between hover:border-emerald-500/50 transition-all shadow-xl space-y-3">
                <div className="space-y-2">
                  <span className="text-[10px] px-2 py-0.5 bg-cyan-950 text-cyan-300 rounded border border-cyan-800 font-bold">Opsi Topik #{idx + 1}</span>
                  <h4 className="text-white font-bold text-sm">{idea.title}</h4>
                  <p className="text-xs text-gray-400"><strong className="text-cyan-400">Konflik:</strong> {idea.conflict}</p>
                  <p className="text-xs text-gray-500"><strong className="text-cyan-400">Alur:</strong> {idea.plot}</p>
                </div>
                <Button onClick={() => handleSelectIdea(idea)} className="w-full !py-2 !text-xs !bg-gradient-to-r !from-cyan-600 !to-blue-600">
                  Pilih Topik Ini <ArrowRight size={14} />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4 animate-in slide-in-from-right-4">
          <div className="p-6 rounded-3xl bg-[#0a0f1d] border border-cyan-950 space-y-4">
            <h3 className="text-sm font-black text-cyan-300 uppercase tracking-wider border-b border-cyan-950 pb-3">Konfirmasi Ide Terpilih</h3>
            <div className="p-4 bg-[#050914] rounded-2xl border border-cyan-900 space-y-2">
              <h4 className="text-white font-bold text-base">{selectedIdea?.title}</h4>
              <p className="text-xs text-gray-300"><strong>Konflik:</strong> {selectedIdea?.conflict}</p>
              <p className="text-xs text-gray-400"><strong>Hook:</strong> {selectedIdea?.hook}</p>
              <p className="text-xs text-gray-500"><strong>Alur:</strong> {selectedIdea?.plot}</p>
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="secondary" onClick={() => setStep(inputMode === 'manual' ? 1 : 2)}>Pilih Topik Lain</Button>
              <Button onClick={handleExecuteFullProduction} isLoading={loading} className="flex-1 !bg-gradient-to-r !from-emerald-600 !to-teal-500">
                Mulai Eksekusi Produksi (Naskah & Visual Terkunci 100%) <ArrowRight size={16} />
              </Button>
            </div>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-6 animate-in zoom-in">
          <div className="p-6 rounded-3xl bg-[#0a0f1d] border border-emerald-800/60 shadow-2xl space-y-6">
            <div className="flex justify-between items-center border-b border-emerald-950 pb-4">
              <h3 className="text-lg font-black text-emerald-400 flex items-center gap-2">
                <Check size={20} /> PRODUKSI SELESAI ({formData.category})
              </h3>
              <Button variant="secondary" onClick={() => setStep(1)} className="!py-2 !px-4 text-xs">
                <RefreshCw size={14} /> Buat Cerita Baru
              </Button>
            </div>

            {scriptAndRenderResult.compositeUrl && (
              <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-800 shadow-xl space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider">STORYBOARD PRODUCTION DOCUMENT (100% Terkunci)</span>
                  <Button onClick={() => downloadImage(scriptAndRenderResult.compositeUrl, 'storyboard-multichar.png')} className="!py-1.5 !px-3 text-xs">
                    <Download size={14} /> Unduh Storyboard (PNG)
                  </Button>
                </div>
                <img src={scriptAndRenderResult.compositeUrl} className="w-full rounded-xl border border-cyan-900" />
              </div>
            )}

            <div className="p-6 rounded-3xl bg-[#060a14] border border-cyan-950 space-y-4">
              <div className="flex justify-between items-center border-b border-cyan-950 pb-3">
                <h3 className="text-sm font-black text-cyan-300 uppercase tracking-wider">Naskah Dialog & Adegan Multi-Karakter Beserta Prompt AI Video (Terkunci 10 Detik per Shot)</h3>
                <button onClick={() => { if (copyToClipboard(scriptAndRenderResult.script)) { setCopiedScript(true); setTimeout(() => setCopiedScript(false), 2000); } }} className="px-3 py-1 bg-cyan-950 text-cyan-300 rounded-lg text-xs font-bold border border-cyan-800 flex items-center gap-1.5 cursor-pointer">
                  {copiedScript ? <Check size={14} className="text-emerald-400"/> : <Copy size={14}/>} {copiedScript ? "Tersalin!" : "Salin Semua Naskah"}
                </button>
              </div>
              <div className="space-y-4">
                {scriptAndRenderResult.shots.map((shot, sIdx) => {
                  const globalIdx = `mc-comb-${sIdx}`;
                  const shotBlocks = scriptAndRenderResult.script.split(/(?=\[?SHOT \d+)/i).map(b => b.trim()).filter(Boolean);
                  const matchingBlock = shotBlocks.find(b => b.includes(`SHOT 0${shot.id}`) || b.includes(`SHOT ${shot.id}`)) || `[SHOT 0${shot.id} | ${shot.timeRange}]\n- Aksi: ${shot.action}`;
                  
                  return (
                    <div key={globalIdx} className="flex flex-col md:flex-row gap-4 bg-[#050914] p-4 rounded-xl border border-cyan-950">
                      <div className="w-full md:w-56 aspect-video bg-black rounded-lg overflow-hidden border border-cyan-900 shrink-0">
                        {shot.img ? <img src={shot.img} className="w-full h-full object-cover"/> : <div className="text-xs text-gray-500 flex h-full items-center justify-center">Gagal render</div>}
                      </div>
                      <div className="flex-1 space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-amber-400 font-mono">SHOT {shot.id} [{shot.timeRange || '00:00 - 00:10'}] (Terkubur & Sinkron)</span>
                          <button 
                            onClick={() => copyCombinedShotCard(shot, matchingBlock, globalIdx)}
                            className="text-[10px] px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded border border-emerald-800 flex items-center gap-1.5 font-bold transition-colors cursor-pointer shadow-md"
                          >
                            {copiedShotIndex === globalIdx ? <Check size={13} className="text-emerald-400"/> : <Copy size={13}/>} {copiedShotIndex === globalIdx ? "Shot & Prompt Disalin!" : "Salin Per Shot Matang"}
                          </button>
                        </div>
                        <div className="text-xs font-mono text-cyan-100 whitespace-pre-wrap leading-relaxed bg-[#0a0f1d] p-3 rounded-lg border border-cyan-950">{matchingBlock.trim()}</div>
                        <div className="p-3 bg-[#0a0f1d] rounded-lg border border-cyan-950 text-xs font-mono text-emerald-200">
                          <span className="text-[10px] text-cyan-400 uppercase font-bold block mb-1">Master AI Video Prompt (English):</span>
                          {shot.prompt}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="space-y-4 hidden">
              {/* Fallback hidden container */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ImageStudio = () => {
  const [subTab, setSubTab] = useState('firstframe');
  const [ffImages, setFfImages] = useState({ character: null, outfit: null, location: null, product: null });
  const [ffData, setFfData] = useState({
    style: OPTIONS.imageStyles[0], pose: OPTIONS.poses[0], angle: 'Medium Shot Standard', 
    expression: OPTIONS.expressions[0], ratio: '16:9', notes: ''
  });
  const [ffResult, setFfResult] = useState(null);
  const [ffHistory, setFfHistory] = useState([]);
  const [ffLoading, setFfLoading] = useState(false);

  const [genPrompt, setGenPrompt] = useState('');
  const [genRefs, setGenRefs] = useState([null]);
  const [genRatio, setGenRatio] = useState('1:1');
  const [genCount, setGenCount] = useState('2');
  const [genResults, setGenResults] = useState([]);
  const [genLoading, setGenLoading] = useState(false);

  const handleGenerateFirstFrame = async () => {
    setFfLoading(true);
    try {
      const inputs = [];
      if (ffImages.character) inputs.push(ffImages.character);
      if (ffImages.outfit) inputs.push(ffImages.outfit);
      if (ffImages.location) inputs.push(ffImages.location);
      if (ffImages.product) inputs.push(ffImages.product);

      const prompt = `
100% LOCKED 1:1 FIRST FRAME THUMBNAIL: Render exact details verbatim:
Artistic Style: ${ffData.style}.
Pose: ${ffData.pose}.
Camera Angle: ${ffData.angle}.
Facial Expression: ${ffData.expression}.
Custom Details: ${ffData.notes || 'Masterpiece lighting, crisp focus, photorealistic 8k render'}.
Strict: Pure visual photography, no watermarks, no subtitles, no graphic text overlay.
      `.trim();

      const img = await callGeminiImage(prompt, inputs, ffData.ratio);
      setFfResult(img);
      setFfHistory(prev => [{ id: Date.now(), img, ratio: ffData.ratio }, ...prev]);
    } catch (err) {
      console.error(err);
    } finally {
      setFfLoading(false);
    }
  };

  const handleGenerateGeneral = async () => {
    if (!genPrompt.trim()) return;
    setGenLoading(true);
    setGenResults([]);
    try {
      const inputs = genRefs.filter(Boolean);
      const count = parseInt(genCount, 10) || 1;
      const results = [];
      
      for (let i = 0; i < count; i++) {
        const fullPrompt = `100% LOCKED 1:1 VISUAL RENDER: ${genPrompt.trim()}\n\nCinematic Masterpiece, Ultra-HD, perfectly calibrated color depth, sharp definition. Variation ${i+1}.`;
        const img = await callGeminiImage(fullPrompt, inputs, genRatio);
        results.push({ id: Date.now() + i, img });
      }
      setGenResults(results);
    } catch (err) {
      console.error(err);
    } finally {
      setGenLoading(false);
    }
  };

  const handleUpdateGenRef = (idx, data) => {
    const next = [...genRefs];
    next[idx] = data;
    if (data !== null && idx === next.length - 1 && next.length < 6) {
      next.push(null);
    }
    setGenRefs(next);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {(ffLoading || genLoading) && <GeneratingOverlay message="Merender gambar visual definisi tinggi via Gemini Image Engine..." />}

      <div className="flex gap-2 p-1.5 bg-[#0a0f1d] rounded-2xl border border-cyan-950 w-fit">
        <button
          onClick={() => setSubTab('firstframe')}
          className={`px-5 py-2 rounded-xl text-xs font-bold transition-all ${
            subTab === 'firstframe' ? 'bg-cyan-500 text-[#050b14] shadow-md shadow-cyan-500/30' : 'text-gray-400 hover:text-white'
          }`}
        >
          First Frame Thumbnail
        </button>
        <button
          onClick={() => setSubTab('general')}
          className={`px-5 py-2 rounded-xl text-xs font-bold transition-all ${
            subTab === 'general' ? 'bg-cyan-500 text-[#050b14] shadow-md shadow-cyan-500/30' : 'text-gray-400 hover:text-white'
          }`}
        >
          Studio Visual Bebas (Multi-Image)
        </button>
      </div>

      {subTab === 'firstframe' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6 p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md">
            <div>
              <span className="text-xs font-bold text-gray-300 block mb-3 uppercase tracking-wider">Slot Referensi Karakter & Objek</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <ImageUploadSlot compact={true} label="Karakter" value={ffImages.character} onUpload={d => setFfImages({...ffImages, character: d})} onRemove={() => setFfImages({...ffImages, character: null})} />
                <ImageUploadSlot compact={true} label="Outfit" value={ffImages.outfit} onUpload={d => setFfImages({...ffImages, outfit: d})} onRemove={() => setFfImages({...ffImages, outfit: null})} />
                <ImageUploadSlot compact={true} label="Lokasi" value={ffImages.location} onUpload={d => setFfImages({...ffImages, location: d})} onRemove={() => setFfImages({...ffImages, location: null})} />
                <ImageUploadSlot compact={true} label="Produk" value={ffImages.product} onUpload={d => setFfImages({...ffImages, product: d})} onRemove={() => setFfImages({...ffImages, product: null})} />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormGroup label="Artistic Style">
                <Select options={OPTIONS.imageStyles} value={ffData.style} onChange={e => setFfData({...ffData, style: e.target.value})} />
              </FormGroup>
              <FormGroup label="Pose Karakter">
                <Select options={OPTIONS.poses} value={ffData.pose} onChange={e => setFfData({...ffData, pose: e.target.value})} />
              </FormGroup>
              <FormGroup label="Angle Kamera">
                <Select options={OPTIONS.cameraAngles} value={ffData.angle} onChange={e => setFfData({...ffData, angle: e.target.value})} />
              </FormGroup>
              <FormGroup label="Ekspresi Wajah">
                <Select options={OPTIONS.expressions} value={ffData.expression} onChange={e => setFfData({...ffData, expression: e.target.value})} />
              </FormGroup>
              <FormGroup label="Aspek Rasio">
                <Select options={OPTIONS.aspectRatios} value={ffData.ratio} onChange={e => setFfData({...ffData, ratio: e.target.value})} />
              </FormGroup>
              <FormGroup label="Catatan Aksi Tambahan">
                <Input placeholder="Contoh: Pencahayaan neon biru dan aksen emas di latar belakang" value={ffData.notes} onChange={e => setFfData({...ffData, notes: e.target.value})} />
              </FormGroup>
            </div>

            <Button onClick={handleGenerateFirstFrame} isLoading={ffLoading} className="w-full">
              <Camera size={18} /> GENERATE FIRST FRAME HOOK
            </Button>
          </div>

          <div className="space-y-6">
            {ffResult ? (
              <div className="p-5 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-800/60 shadow-xl space-y-3">
                <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider block">Hasil Frame Utama</span>
                <div className="rounded-2xl overflow-hidden bg-black border border-cyan-950 flex items-center justify-center max-h-[380px]">
                  <img src={ffResult} alt="First Frame" className="w-full h-full object-contain" />
                </div>
                <Button onClick={() => downloadImage(ffResult, 'first-frame.png')} variant="secondary" className="w-full text-xs">
                  <Download size={14} /> Download Resolusi Penuh
                </Button>
              </div>
            ) : (
              <div className="p-8 rounded-3xl bg-[#0a0f1d]/50 border border-cyan-950 text-center text-gray-500 text-xs">
                Visual First Frame yang di-generate akan muncul di sini.
              </div>
            )}

            {ffHistory.length > 0 && (
              <div className="p-5 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950 space-y-3">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Galeri Sesi Ini</span>
                <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto custom-scrollbar">
                  {ffHistory.map(item => (
                    <div key={item.id} className="relative rounded-xl overflow-hidden aspect-video border border-cyan-950 cursor-pointer group" onClick={() => setFfResult(item.img)}>
                      <img src={item.img} alt="Thumb" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6 p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md">
          <FormGroup label="Deskripsi Visual Prompt Bebas" tip="Tulis topik atau ide visual persis">
            <Textarea 
              placeholder="Deskripsikan konsep visual persis yang ingin dirender..." 
              value={genPrompt} 
              onChange={e => setGenPrompt(e.target.value)} 
              rows={4} 
            />
          </FormGroup>

          <div>
            <span className="text-xs font-bold text-gray-300 block mb-2 uppercase tracking-wider">Gambar Referensi Estetika (Maksimal 6)</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              {genRefs.map((r, i) => (
                <ImageUploadSlot key={i} compact={true} label={`Ref ${i+1}`} value={r} onUpload={d => handleUpdateGenRef(i, d)} onRemove={() => {
                  const next = genRefs.filter((_, idx) => idx !== i);
                  if (next.length === 0 || next[next.length - 1] !== null) next.push(null);
                  setGenRefs(next);
                }} />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Aspek Rasio">
              <Select options={OPTIONS.aspectRatios} value={genRatio} onChange={e => setGenRatio(e.target.value)} />
            </FormGroup>
            <FormGroup label="Jumlah Variasi Foto">
              <Select options={['1 Foto', '2 Foto', '3 Foto', '4 Foto']} value={genCount} onChange={e => setGenCount(e.target.value.split(' ')[0])} />
            </FormGroup>
          </div>

          <Button onClick={handleGenerateGeneral} isLoading={genLoading} className="w-full">
            <Sparkles size={18} /> GENERATE GAMBAR STUDIO
          </Button>

          {genResults.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-cyan-950">
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider block">Hasil Rendering Visual ({genResults.length} Variasi)</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                {genResults.map((item, idx) => (
                  <div key={item.id} className="p-3 rounded-2xl bg-[#060a14] border border-cyan-900/60 flex flex-col gap-2">
                    <div className="aspect-square rounded-xl overflow-hidden bg-black border border-cyan-950">
                      <img src={item.img} alt={`Render ${idx+1}`} className="w-full h-full object-cover" />
                    </div>
                    <Button onClick={() => downloadImage(item.img, `render-${idx+1}.png`)} variant="secondary" className="w-full !py-2 text-xs">
                      <Download size={13} /> Unduh PNG
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const AffiliatePromptGenerator = () => {
  const [images, setImages] = useState({ character: null, outfit: null, location: null, products: [null, null, null, null] });
  const [formData, setFormData] = useState({
    duration: '30 detik', gender: 'Wanita', age: '25', productType: '', characterAction: '',
    videoStyle: 'UGC Video', cameraAngles: ['Eye Level'], cameraMovements: ['Static Locked-Off Master'], 
    useDialog: false, dialogText: '', fitCheck: false, textOverlay: true, overlayStyle: 'Pop-Up Zoom Neon', 
    notes: '', voiceOver: false, voiceOverText: '', aspectRatio: '9:16'
  });
  const [result, setResult] = useState('');
  const [storyboardImage, setStoryboardImage] = useState(null);
  const [firstFrameImage, setFirstFrameImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copiedShotIndex, setCopiedShotIndex] = useState(null);
  const [copiedAllPrompts, setCopiedAllPrompts] = useState(false);

  const copySingleShotScript = (shotText, idx) => {
    if (copyToClipboard(shotText)) {
      setCopiedShotIndex(idx);
      setTimeout(() => setCopiedShotIndex(null), 2000);
    }
  };

  const toggleCameraAngle = (angle) => {
    setFormData(prev => {
      const isSelected = prev.cameraAngles.includes(angle);
      if (!isSelected && prev.cameraAngles.length >= 3) return prev;
      return {
        ...prev,
        cameraAngles: isSelected ? prev.cameraAngles.filter(a => a !== angle) : [...prev.cameraAngles, angle]
      };
    });
  };

  const toggleCameraMovement = (mv) => {
    setFormData(prev => {
      const isSelected = prev.cameraMovements.includes(mv);
      if (!isSelected && prev.cameraMovements.length >= 4) return prev;
      return {
        ...prev,
        cameraMovements: isSelected ? prev.cameraMovements.filter(m => m !== mv) : [...prev.cameraMovements, mv]
      };
    });
  };

  const handleGenerate = async () => {
    setLoading(true);
    setStoryboardImage(null);
    setFirstFrameImage(null);
    try {
      const imageInputs = [];
      if (images.character) imageInputs.push(images.character);
      if (images.outfit) imageInputs.push(images.outfit);
      if (images.location) imageInputs.push(images.location);
      images.products.forEach((img) => {
        if (img) imageInputs.push(img);
      });

      const productName = formData.productType.trim() || "Produk Pilihan";
      const extraContext = formData.notes.trim() ? `${formData.notes.trim()}.` : "";
      
      const fullPrompt = `
DURASI TARGET TOTAL: ${formData.duration}. 
Sebagai Senior Director, buatkan satu naskah master komersial affiliate promosi produk "${productName}" yang utuh, tersinkron konsisten, dan mengalir mulus tanpa terputus.
- Karakter: ${formData.gender}, Usia ${formData.age} tahun dengan pakaian, wardrobe, dan ciri fisik yang WAJIB 100% KONSISTEN SAMA PERSIS di setiap shot/adegan tanpa ada perubahan warna atau bentuk baju.
- Aksi Karakter: ${formData.characterAction || 'Menunjukkan fungsi utama produk secara antusias'}
- Style: ${formData.videoStyle}
- Detail Tambahan: ${extraContext}

ATURAN KETAT STRUKTUR NASKAH MASTER PER SHOT:
Wajib dipecah secara berurutan menjadi beberapa shot dengan durasi TEPAT 10 DETIK padat isi secara konsisten (Mulai dari SHOT 01, SHOT 02, SHOT 03, dst sesuai durasi ${formData.duration}).
Setiap shot WAJIB menggunakan format tag judul wajib di baris pertama:
[SHOT 01 | 00:00 - 00:10]
- Visual / Aksi: ...
- Dialog / Interaksi: ...
- Prompt Video AI (Bahasa Inggris spesifik): ...
      `.trim();

      const responseText = await callGeminiText(fullPrompt, imageInputs);
      setResult(responseText);

      try {
        const storyboardPrompt = `100% LOCKED 1:1 ABSOLUTE WARDROBE & FACE CONSISTENCY SEQUENTIAL STORYBOARD GRID: Create a multi-panel storyboard grid showing a perfectly connected and synchronized sequence for a commercial video about ${productName} adhering strictly to the theme: "${formData.characterAction || productName}". 
[CRITICAL WARDROBE & FACE LOCK]: Every single panel in this grid MUST feature the EXACT SAME character, wearing the EXACT SAME clothing, exact same outfit colors, exact same hairstyle, and exact same facial features matching the reference images. The character's wardrobe must remain 100% identical across all grid panels without any variation. The story flows seamlessly from hook to CTA. Character: ${formData.gender}, ${formData.age}yo. Style: ${formData.videoStyle}, clean professional studio color grading. Pure visual composition without text labels.`;
        const imgData = await callGeminiImage(storyboardPrompt, imageInputs, formData.aspectRatio);
        if (imgData) setStoryboardImage(imgData);
      } catch (err) {
        console.warn("Storyboard grid generator:", err);
      }

      try {
        const firstFramePrompt = `100% LOCKED 1:1 THUMBNAIL: Render the exact opening hook frame for ${formData.gender}, ${formData.age} years old talent with ${productName}. Pose: dynamic engaging look to the camera. Natural sharp studio lighting. Rasio ${formData.aspectRatio} composition. Pure visual image without text labels.`;
        const ffData = await callGeminiImage(firstFramePrompt, imageInputs, formData.aspectRatio);
        if (ffData) setFirstFrameImage(ffData);
      } catch (err) {
        console.warn("First frame generator:", err);
      }

    } catch (err) {
      console.error("Affiliate prompt error:", err);
    } finally {
      setLoading(false);
    }
  };

  const validShots = result
    ? result.split(/(?=\[?SHOT \d+)/i).map(b => b.trim()).filter(Boolean).filter(shotBlock => shotBlock.length > 5 && (/SHOT \d+/i.test(shotBlock)))
    : [];

  const copyAllPrompts = () => {
    const allPromptsText = validShots.map(shot => {
      const lines = shot.split('\n');
      return lines.join('\n');
    }).join('\n\n');
    if (copyToClipboard(allPromptsText)) {
      setCopiedAllPrompts(true);
      setTimeout(() => setCopiedAllPrompts(false), 2000);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      {loading && <GeneratingOverlay message="Menyusun naskah affiliate konversi 10 detik padat per shot secara sinkron & rendering storyboard visual..." />}

      <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-4">
        <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
          <Layers size={18} className="text-cyan-400" />
          <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Slot Referensi Visual Subjek & Produk</h3>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <ImageUploadSlot compact={true} label="Karakter Talent" value={images.character} onUpload={(d) => setImages({...images, character: d})} onRemove={() => setImages({...images, character: null})} />
          <ImageUploadSlot compact={true} label="Wardrobe / Outfit" value={images.outfit} onUpload={(d) => setImages({...images, outfit: d})} onRemove={() => setImages({...images, outfit: null})} />
          <ImageUploadSlot compact={true} label="Lokasi / Studio" value={images.location} onUpload={(d) => setImages({...images, location: d})} onRemove={() => setImages({...images, location: null})} />
        </div>

        <div className="pt-2">
          <span className="text-xs font-bold text-gray-400 block mb-2 uppercase tracking-wider">Referensi Produk Komersial (Maksimal 4 Slot)</span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[0,1,2,3].filter(i => i === 0 || images.products[i-1] !== null).map(i => (
              <ImageUploadSlot 
                key={i} 
                compact={true}
                label={`Produk ${i+1}`} 
                value={images.products[i]} 
                onUpload={(d) => { const np = [...images.products]; np[i] = d; setImages({...images, products: np}); }} 
                onRemove={() => { const np = [...images.products]; np[i] = null; setImages({...images, products: np}); }} 
              />
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4 p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md">
          <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
            <Sliders size={18} className="text-amber-400" />
            <h3 className="text-sm font-black text-gray-200 uppercase tracking-wider">Spesifikasi Target Video</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Durasi Produksi">
              <Select options={['10 detik', '20 detik', '30 detik', '40 detik', '50 detik', '60 detik']} value={formData.duration} onChange={e => setFormData({...formData, duration: e.target.value})} />
            </FormGroup>
            <FormGroup label="Jenis Kelamin Talent">
              <Select options={['Wanita', 'Pria']} value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value})} />
            </FormGroup>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Rentang Usia">
              <Select options={['18-22 (Gen Z)', '23-28 (Young Adult)', '30-35 (Professional)', '40+ (Mature)'] } value={formData.age} onChange={e => setFormData({...formData, age: e.target.value})} />
            </FormGroup>
            <FormGroup label="Format Gaya Video">
              <Select options={['UGC Video', 'Cinematic Video', 'Commercial Studio Ads', 'POV Tangan Unboxing', 'Outfit Transition Lookbook']} value={formData.videoStyle} onChange={e => setFormData({...formData, videoStyle: e.target.value})} />
            </FormGroup>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Aspek Rasio Frame">
              <Select options={OPTIONS.aspectRatios} value={formData.aspectRatio} onChange={e => setFormData({...formData, aspectRatio: e.target.value})} />
            </FormGroup>
          </div>

          <FormGroup label="Nama & Jenis Produk">
            <Input placeholder="Contoh: Brightening Glow Serum 30ml / Jaket Bomber Waterproof" value={formData.productType} onChange={e => setFormData({...formData, productType: e.target.value})} />
          </FormGroup>

          <FormGroup label="Aksi Utama Karakter">
            <Input placeholder="Contoh: Mengoleskan 2 tetes serum dan memperlihatkan efek glowing instan" value={formData.characterAction} onChange={e => setFormData({...formData, characterAction: e.target.value})} />
          </FormGroup>

          <div className="space-y-3 pt-2">
            <div>
              <span className="text-xs font-bold text-gray-300 block mb-1.5">Angle Kamera ({formData.cameraAngles.length}/3 dipilih)</span>
              <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-2 bg-[#060a14] rounded-xl border border-cyan-950 custom-scrollbar">
                {OPTIONS.cameraAngles.map(angle => (
                  <button
                    key={angle}
                    type="button"
                    onClick={() => toggleCameraAngle(angle)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      formData.cameraAngles.includes(angle)
                        ? 'bg-cyan-500 text-[#050b14] font-bold shadow-md shadow-cyan-500/20'
                        : 'bg-cyan-950/40 text-gray-400 hover:text-cyan-200 border border-cyan-900/40'
                    }`}
                  >
                    {angle}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="text-xs font-bold text-gray-300 block mb-1.5">Gerakan Kamera ({formData.cameraMovements.length}/4 dipilih)</span>
              <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-2 bg-[#060a14] rounded-xl border border-cyan-950 custom-scrollbar">
                {OPTIONS.affiliateMovements.map(mv => (
                  <button
                    key={mv}
                    type="button"
                    onClick={() => toggleCameraMovement(mv)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      formData.cameraMovements.includes(mv)
                        ? 'bg-amber-400 text-[#0f172a] font-bold shadow-md shadow-amber-500/20'
                        : 'bg-cyan-950/40 text-gray-400 hover:text-amber-200 border border-cyan-900/40'
                    }`}
                  >
                    {mv}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4 p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
              <Compass size={18} className="text-teal-400" />
              <h3 className="text-sm font-black text-gray-200 uppercase tracking-wider">Audio & Overlay Penjualan</h3>
            </div>

            <Toggle label="Sertakan Dialog Bicara Talent" checked={formData.useDialog} onChange={e => setFormData({...formData, useDialog: e.target.checked})} badge="Lip-sync" />
            {formData.useDialog && (
              <Textarea 
                placeholder="Tuliskan dialog spesifik (atau kosongkan agar disusun otomatis oleh Direktur AI)..." 
                value={formData.dialogText} 
                onChange={e => setFormData({...formData, dialogText: e.target.value})} 
                rows={3} 
              />
            )}

            <Toggle label="Sertakan Narasi Voice Over (VO)" checked={formData.voiceOver} onChange={e => setFormData({...formData, voiceOver: e.target.checked})} badge="Audio Suara Latar" />
            {formData.voiceOver && (
              <Textarea 
                placeholder="Tuliskan teks voice over komersial di sini..." 
                value={formData.voiceOverText} 
                onChange={e => setFormData({...formData, voiceOverText: e.target.value})} 
                rows={3} 
              />
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Toggle label="Text Overlay Animatif" checked={formData.textOverlay} onChange={e => setFormData({...formData, textOverlay: e.target.checked})} />
              {formData.textOverlay && (
                <Select options={['Pop-Up Zoom Neon', 'Typewriter Minimalis', 'Slide-In Halus E-Commerce', 'Kinetic Bold Headline']} value={formData.overlayStyle} onChange={e => setFormData({...formData, overlayStyle: e.target.value})} />
              )}
            </div>

            <FormGroup label="Instruksi Khusus / Mood Vibe">
              <Textarea placeholder="Contoh: Tone warna mewah ala Korea, pencahayaan golden afternoon, mood meyakinkan..." value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} rows={3} />
            </FormGroup>
          </div>

          <Button onClick={handleGenerate} isLoading={loading} className="w-full">
            <Megaphone size={18} /> GENERATE AFFILIATE PROMPT & VISUALS
          </Button>
        </div>
      </div>

      {(storyboardImage || firstFrameImage) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in zoom-in">
          {storyboardImage && (
            <div className="p-5 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-900/60 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-2">
                  <LayoutGrid size={15} /> Storyboard Grid Visual Konsisten ({formData.aspectRatio})
                </span>
                <button onClick={() => downloadImage(storyboardImage, 'affiliate-storyboard.png')} className="text-xs text-cyan-400 hover:text-cyan-200 flex items-center gap-1 font-semibold">
                  <Download size={14} /> Unduh
                </button>
              </div>
              <div className="rounded-2xl overflow-hidden border border-cyan-950 aspect-video bg-black flex items-center justify-center">
                <img src={storyboardImage} alt="Storyboard Grid" className="w-full h-full object-cover" />
              </div>
            </div>
          )}

          {firstFrameImage && (
            <div className="p-5 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-900/60 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-2">
                  <Eye size={15} /> First Frame Hook Thumbnail ({formData.aspectRatio})
                </span>
                <button onClick={() => downloadImage(firstFrameImage, 'first-frame.png')} className="text-xs text-amber-400 hover:text-amber-200 flex items-center gap-1 font-semibold">
                  <Download size={14} /> Unduh
                </button>
              </div>
              <div className="rounded-2xl overflow-hidden border border-cyan-950 max-h-[340px] aspect-[9/16] mx-auto bg-black flex items-center justify-center">
                <img src={firstFrameImage} alt="First Frame" className="w-full h-full object-cover" />
              </div>
            </div>
          )}
        </div>
      )}

      {validShots.length > 0 && (
        <div className="p-6 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-800/60 shadow-2xl space-y-6 animate-in fade-in">
          <div className="flex justify-between items-center border-b border-cyan-950 pb-3">
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Naskah Master Komersial (Konsisten 10 Detik Per Shot)</span>
            <button 
              onClick={copyAllPrompts}
              className="px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 rounded-lg text-xs font-bold border border-cyan-800 flex items-center gap-1.5 cursor-pointer"
            >
              {copiedAllPrompts ? <Check size={14} className="text-emerald-400"/> : <Copy size={14}/>} {copiedAllPrompts ? "Semua Disalin!" : "Salin Semua Naskah"}
            </button>
          </div>
          <div className="space-y-3">
            {validShots.map((shotBlock, sIdx) => {
              const globalIdx = `aff-${sIdx}`;
              const shotTitleMatch = shotBlock.match(/\[?SHOT \d+[^\]\n]*\]?/i);
              const shotTitle = shotTitleMatch ? shotTitleMatch[0] : `Shot #${sIdx + 1}`;
              return (
                <div key={globalIdx} className="bg-[#050914] p-4 rounded-xl border border-cyan-950/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-amber-400 font-mono">{shotTitle}</span>
                    <button 
                      onClick={() => copySingleShotScript(shotBlock.trim(), globalIdx)}
                      className="text-[10px] px-2.5 py-1 bg-[#0a0f1d] hover:bg-cyan-950 text-cyan-300 rounded border border-cyan-900 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedShotIndex === globalIdx ? <Check size={12} className="text-emerald-400"/> : <Copy size={12}/>} {copiedShotIndex === globalIdx ? "Tersalin!" : "Salin Shot Ini"}
                    </button>
                  </div>
                  <div className="text-xs font-mono text-cyan-100 whitespace-pre-wrap leading-relaxed">{shotBlock.trim()}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

const StoryboardGenerator = ({ savedCharacters, setActiveTab }) => {
  const [images, setImages] = useState({ char: [null, null], outfit: [null, null], loc: [null, null] });
  const [useSavedChar, setUseSavedChar] = useState(false);
  const [selectedCharId, setSelectedCharId] = useState('');
  const [storyDesc, setStoryDesc] = useState('');
  const [numShots, setNumShots] = useState('4');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [style, setStyle] = useState(OPTIONS.imageStyles[0]);
  
  const [includeDialogue, setIncludeDialogue] = useState(false);
  const [characterDialogueText, setCharacterDialogueText] = useState('');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressMsg, setProgressMsg] = useState('');
  const [compositeCanvasUrl, setCompositeCanvasUrl] = useState(null);
  const [generatedScriptResult, setGeneratedScriptResult] = useState('');
  const [renderedShotsList, setRenderedShotsList] = useState([]);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedShotIndex, setCopiedShotIndex] = useState(null);

  const handleUpdateImage = (group, idx, data) => {
    const next = [...images[group]];
    next[idx] = data;
    setImages({...images, [group]: next});
  };

  const handleGenerateStoryboard = async () => {
    if (!storyDesc.trim()) return;
    setIsGenerating(true);
    setCompositeCanvasUrl(null);
    setGeneratedScriptResult('');
    setRenderedShotsList([]);
    
    try {
      setProgressMsg("Direktur AI menganalisis premis & merumuskan naskah shot panel...");
      
      const charRefName = useSavedChar && selectedCharId 
        ? savedCharacters.find(c => String(c.id) === String(selectedCharId))?.name 
        : "Subjek Talent Utama";

      const dialogueInstruction = includeDialogue 
        ? (characterDialogueText.trim() 
            ? `Sertakan dialog spesifik atau interaksi bicara karakter: "${characterDialogueText.trim()}".` 
            : "Sertakan dialog interaktif yang otomatis dibuatkan oleh AI secara sangat relevan, natural, dan sinkron dengan adegan masing-masing shot.")
        : "Tanpa dialog bicara karakter (fokus visual murni).";

      const promptPlanning = `
JSON_OUTPUT_REQUIRED
Sebagai sutradara sinematografi, susun naskah storyboard untuk cerita berikut secara SANGAT RELEVAN dan berfokus mutlak pada topik: "${storyDesc}"
Premis: ${storyDesc}
Jumlah Shot: ${numShots} (Setiap shot berdurasi TEPAT 10 DETIK padat isi)
Karakter: ${charRefName}
${dialogueInstruction}

[CRITICAL WARDROBE & FACE LOCK]: Every single shot in this storyboard MUST maintain 100% strict absolute consistency: the exact same character, exact same clothing, exact same outfit colors, exact same hairstyle, and exact same facial features across all shots. The wardrobe must not change.

Berikan respon JSON MURNI tanpa backtick dengan format persis:
[
  { "id": 1, "action": "Aksi utama talent", "dialogue": "Dialog karakter (jika ada/dibuat otomatis)", "cameraAngle": "Angle kamera", "description": "Deskripsi visual adegan untuk generator gambar AI dengan menjaga konsistensi mutlak baju, wajah, dan subjek dari referensi" }
]
      `.trim();

      const textRes = await callGeminiText(promptPlanning);
      let parsed = parseJsonSafe(textRes, [
        { id: 1, action: "Aksi awal pembuka", dialogue: includeDialogue ? "Dialog otomatis yang relevan" : "", cameraAngle: "Eye Level", description: "Visual sinematik pembuka konsisten" }
      ]).slice(0, parseInt(numShots, 10));

      const scriptSummaryText = parsed.map(s => `SHOT 0${s.id} [00:00 - 00:10] (${s.cameraAngle.toUpperCase()})\nAksi: ${s.action}\n${includeDialogue && s.dialogue ? `Dialog: "${s.dialogue}"\n` : ''}Deskripsi: ${s.description}\n`).join('\n');
      setGeneratedScriptResult(scriptSummaryText);

      const inputs = [];
      if (useSavedChar && selectedCharId) {
        const charObj = savedCharacters.find(c => String(c.id) === String(selectedCharId));
        if (charObj && charObj.image) {
          const mime = charObj.image.split(';')[0].split(':')[1];
          const data = charObj.image.split(',')[1];
          inputs.push({ mimeType: mime, data });
        }
      }
      images.char.forEach(img => img && inputs.push(img));
      images.outfit.forEach(img => img && inputs.push(img));
      images.loc.forEach(img => img && inputs.push(img));

      const renderedShots = [];
      for (let i = 0; i < parsed.length; i++) {
        const s = parsed[i];
        setProgressMsg(`Merender visual shot ${i + 1}: ${s.action.substring(0, 30)}...`);
        const shotPrompt = `[ABSOLUTE 100% WARDROBE, OUTFIT COLOR & FACE LOCK]: You MUST clone the EXACT clothing style, exact outfit colors, fabric, and facial features from the provided reference images. DO NOT alter the outfit, colors, or appearance across shots.\n\n[SCENE DETAILS]\n- Story Context: "${storyDesc}"\n- Scene Action: ${s.action}\n- Visual Description: "${s.description}"\n- Camera Angle: ${s.cameraAngle}\n- Art Style: ${style}\n\n[CRITICAL]: The character's clothes, colors, and face must remain 100% identical and synchronized across all panels. Professional cinematic composition, no text.`.trim();
        const img = await callGeminiImage(shotPrompt, inputs, aspectRatio);
        renderedShots.push({ ...s, img });
      }

      setRenderedShotsList(renderedShots);
      setProgressMsg("Merangkai panel visual ke dalam Dokumen Storyboard Composite...");

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      const cols = renderedShots.length <= 2 ? 2 : renderedShots.length <= 4 ? 2 : 3;
      const rows = Math.ceil(renderedShots.length / cols);
      const cellWidth = 720;
      const cellImgHeight = aspectRatio === '9:16' ? 1280 : aspectRatio === '1:1' ? 720 : 405;
      const cellTextHeight = includeDialogue ? 340 : 280;
      const cellTotalHeight = cellImgHeight + cellTextHeight;
      const pad = 40;
      const headerH = 140;

      canvas.width = cols * cellWidth + (cols + 1) * pad;
      canvas.height = headerH + rows * cellTotalHeight + (rows + 1) * pad;

      ctx.fillStyle = '#060a14';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#0e172a';
      ctx.fillRect(pad, pad, canvas.width - (pad * 2), headerH - pad);
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 2;
      ctx.strokeRect(pad, pad, canvas.width - (pad * 2), headerH - pad);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 32px "Segoe UI", Roboto, Helvetica, sans-serif';
      ctx.fillText('STORYBOARD PRODUCTION DOCUMENT (100% WARDROBE & FACE LOCKED)', pad + 40, pad + 55);

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
      ctx.fillText(`PROYEK: ${storyDesc.substring(0, 50)}${storyDesc.length > 50 ? '...' : ''}  |  STYLE: ${style}  |  RATIO: ${aspectRatio}`, pad + 40, pad + 95);

      for (let i = 0; i < renderedShots.length; i++) {
        const item = renderedShots[i];
        const col = i % cols;
        const row = Math.floor(i / cols);
        const x = pad + col * (cellWidth + pad);
        const y = headerH + pad + row * (cellTotalHeight + pad);

        const imgEl = new Image();
        await new Promise((res, rej) => {
          imgEl.onload = res;
          imgEl.onerror = rej;
          imgEl.src = item.img;
        });

        ctx.drawImage(imgEl, x, y, cellWidth, cellImgHeight);

        ctx.fillStyle = '#0f172a';
        ctx.fillRect(x, y + cellImgHeight, cellWidth, cellTextHeight);

        ctx.fillStyle = '#1e293b';
        ctx.fillRect(x, y + cellImgHeight, cellWidth, 45);

        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.strokeRect(x, y, cellWidth, cellTotalHeight);
        
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x, y + cellImgHeight);
        ctx.lineTo(x + cellWidth, y + cellImgHeight);
        ctx.stroke();

        ctx.fillStyle = '#f59e0b';
        ctx.font = 'bold 20px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText(`SHOT 0${item.id}`, x + 25, y + cellImgHeight + 30);

        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 16px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText(`[ ${item.cameraAngle.toUpperCase()} ]`, x + 130, y + cellImgHeight + 29);

        let currentY = y + cellImgHeight + 85;
        const wrapText = (text, startX, startY, maxWidth, lineHeight, fontStyle, color) => {
            ctx.fillStyle = color;
            ctx.font = fontStyle;
            const words = text.split(' ');
            let line = '';
            for(let n = 0; n < words.length; n++) {
                let testLine = line + words[n] + ' ';
                if (ctx.measureText(testLine).width > maxWidth && n > 0) {
                    ctx.fillText(line, startX, startY);
                    line = words[n] + ' ';
                    startY += lineHeight;
                } else {
                    line = testLine;
                }
            }
            ctx.fillText(line, startX, startY);
            return startY + lineHeight;
        };

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText('AKSI:', x + 25, currentY);
        currentY = wrapText(item.action, x + 85, currentY, cellWidth - 110, 24, '18px "Segoe UI", Roboto, Helvetica, sans-serif', '#e2e8f0') + 15;

        if (includeDialogue && item.dialogue) {
          ctx.fillStyle = '#34d399';
          ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText('DIALOG:', x + 25, currentY);
          currentY = wrapText(`"${item.dialogue}"`, x + 105, currentY, cellWidth - 130, 24, 'italic 18px "Segoe UI", Roboto, Helvetica, sans-serif', '#a7f3d0') + 15;
        }

        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 16px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText('VISUAL:', x + 25, currentY);
        wrapText(item.description, x + 95, currentY, cellWidth - 120, 22, '16px "Segoe UI", Roboto, Helvetica, sans-serif', '#94a3b8');
      }

      setCompositeCanvasUrl(canvas.toDataURL('image/png'));
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
      setProgressMsg('');
    }
  };

  const copySingleShotScript = (shotBlock, idx) => {
    if (copyToClipboard(shotBlock)) {
      setCopiedShotIndex(idx);
      setTimeout(() => setCopiedShotIndex(null), 2000);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      {isGenerating && <GeneratingOverlay message={progressMsg || "Menjalankan auto-grid storyboard engine..."} />}

      <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-4">
        <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
          <LayoutGrid size={18} className="text-cyan-400" />
          <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Aset Storyboard Sinematik</h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
          <ImageUploadSlot compact={true} label="Aktor A" value={images.char[0]} onUpload={d => handleUpdateImage('char', 0, d)} onRemove={() => handleUpdateImage('char', 0, null)} />
          <ImageUploadSlot compact={true} label="Aktor B" value={images.char[1]} onUpload={d => handleUpdateImage('char', 1, d)} onRemove={() => handleUpdateImage('char', 1, null)} />
          <ImageUploadSlot compact={true} label="Outfit 1" value={images.outfit[0]} onUpload={d => handleUpdateImage('outfit', 0, d)} onRemove={() => handleUpdateImage('outfit', 0, null)} />
          <ImageUploadSlot compact={true} label="Outfit 2" value={images.outfit[1]} onUpload={d => handleUpdateImage('outfit', 1, d)} onRemove={() => handleUpdateImage('outfit', 1, null)} />
          <ImageUploadSlot compact={true} label="Lokasi 1" value={images.loc[0]} onUpload={d => handleUpdateImage('loc', 0, d)} onRemove={() => handleUpdateImage('loc', 0, null)} />
          <ImageUploadSlot compact={true} label="Lokasi 2" value={images.loc[1]} onUpload={d => handleUpdateImage('loc', 1, d)} onRemove={() => handleUpdateImage('loc', 1, null)} />
        </div>
      </div>

      <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-b border-cyan-950 pb-3">
          <Toggle label="Gunakan Karakter AI Influencer yang Telah Dibuat" checked={useSavedChar} onChange={e => setUseSavedChar(e.target.checked)} />
          {useSavedChar && (
            <div className="w-full sm:w-64">
              {savedCharacters.length === 0 ? (
                <button onClick={() => setActiveTab('influencer')} className="text-xs text-amber-400 hover:underline">
                  + Buat karakter di Influencer Creator
                </button>
              ) : (
                <Select 
                  options={savedCharacters.map(c => ({ value: c.id, label: c.name }))} 
                  value={selectedCharId} 
                  onChange={e => setSelectedCharId(e.target.value)} 
                />
              )}
            </div>
          )}
        </div>

        <FormGroup label="Topik Spesifik & Alur Cerita (Wajib Diisi)" tip="Tulis topik persis yang ingin divisualisasikan">
          <Textarea 
            placeholder="Skincare Anti-Aging untuk Kulit Sensitif" 
            value={storyDesc} 
            onChange={e => setStoryDesc(e.target.value)} 
            rows={4} 
          />
        </FormGroup>

        <div className="space-y-3 p-4 rounded-2xl bg-[#060a14] border border-cyan-950/80">
          <Toggle 
            label="Sertakan Dialog Karakter Berbicara" 
            checked={includeDialogue} 
            onChange={e => setIncludeDialogue(e.target.checked)} 
            badge="Opsional (Auto AI / Manual)" 
          />
          {includeDialogue && (
            <FormGroup label="Ketik Referensi Dialog Karakter (Opsional - Kosongkan jika ingin AI buatkan otomatis)" tip="Jika dikosongkan, AI otomatis menyusun dialog yang sangat sinkron">
              <Input 
                placeholder="Contoh: Kulit glowing berkat formula terbaru ini... (atau biarkan kosong)" 
                value={characterDialogueText} 
                onChange={e => setCharacterDialogueText(e.target.value)} 
              />
            </FormGroup>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <FormGroup label="Jumlah Panel Shot">
            <Select options={['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']} value={numShots} onChange={e => setNumShots(e.target.value)} />
          </FormGroup>
          <FormGroup label="Aspek Rasio Frame">
            <Select options={OPTIONS.aspectRatios} value={aspectRatio} onChange={e => setAspectRatio(e.target.value)} />
          </FormGroup>
          <FormGroup label="Visual Style">
            <Select options={OPTIONS.imageStyles} value={style} onChange={e => setStyle(e.target.value)} />
          </FormGroup>
        </div>

        <Button onClick={handleGenerateStoryboard} isLoading={isGenerating} className="w-full">
          <Clapperboard size={18} /> GENERATE COMPOSITE STORYBOARD DOCUMENT
        </Button>
      </div>

      {compositeCanvasUrl && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-800/80 shadow-2xl space-y-4 animate-in zoom-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-2">
                <MonitorPlay size={16} /> Lembar Dokumen Storyboard Utuh (100% Terkunci Konsisten)
              </span>
              <Button onClick={() => downloadImage(compositeCanvasUrl, 'storyboard-document.png')} className="!py-2 text-xs">
                <Download size={14} /> Download Lembar Storyboard (PNG)
              </Button>
            </div>
            
            <div className="rounded-2xl overflow-hidden border border-cyan-950 bg-black p-2">
              <img src={compositeCanvasUrl} alt="Storyboard Document" className="w-full h-auto rounded-xl shadow-2xl" />
            </div>
          </div>

          {generatedScriptResult && (
            <div className="p-6 rounded-3xl bg-[#0a0f1d]/90 border border-emerald-800/60 shadow-2xl space-y-4 animate-in fade-in">
              <div className="flex justify-between items-center border-b border-emerald-950 pb-3">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                  <FileText size={16} /> Naskah Per-Shot & Detail Adegan Storyboard (Konsisten & Tersinkron)
                </span>
                <button 
                  onClick={() => { if (copyToClipboard(generatedScriptResult)) { setCopiedScript(true); setTimeout(() => setCopiedScript(false), 2000); } }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-950/40 text-emerald-300 border border-emerald-800/50 hover:bg-emerald-900/60 text-xs flex items-center gap-1.5 font-bold cursor-pointer"
                >
                  {copiedScript ? <Check size={14} className="text-emerald-400"/> : <Copy size={14}/>} {copiedScript ? "Naskah Disalin!" : "Salin Seluruh Naskah"}
                </button>
              </div>

              <div className="space-y-3">
                {generatedScriptResult.split(/(?=\bSHOT \d+)/).filter(Boolean).map((shotBlock, sIdx) => (
                  <div key={sIdx} className="bg-[#050914] p-4 rounded-xl border border-cyan-950/80 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-400 font-mono">SHOT #{sIdx + 1}</span>
                      <button 
                        onClick={() => copySingleShotScript(shotBlock.trim(), sIdx)}
                        className="text-[10px] px-2.5 py-1 bg-[#0a0f1d] hover:bg-cyan-950 text-cyan-300 rounded border border-cyan-900 flex items-center gap-1 cursor-pointer font-bold"
                      >
                        {copiedShotIndex === sIdx ? <Check size={12} className="text-emerald-400"/> : <Copy size={12}/>} {copiedShotIndex === sIdx ? "Tersalin!" : "Salin Shot Ini"}
                      </button>
                    </div>
                    <div className="text-xs text-cyan-100 whitespace-pre-wrap font-mono leading-relaxed">{shotBlock.trim()}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const GeneralPromptStudio = () => {
  const [images, setImages] = useState({ char: Array(4).fill(null), outfit: Array(4).fill(null), loc: Array(2).fill(null) });
  const [formData, setFormData] = useState({ numShots: '3', videoStyle: 'Cinematic Movie Short', context: '', duration: '10 detik', voiceOver: false, voiceOverText: '', aspectRatio: '16:9' });
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  const handleUpdateImage = (group, index, data) => {
    const next = [...images[group]];
    next[index] = data;
    setImages({...images, [group]: next});
  };

  const handleGenerate = async () => {
    if (!formData.context.trim()) return;
    setLoading(true);
    try {
      const imageInputs = [];
      let imgDesc = [];
      images.char.forEach((img, i) => img && (imageInputs.push(img), imgDesc.push(`Gambar ${imageInputs.length}: Ref Karakter Aktor ${i+1}`)));
      images.outfit.forEach((img, i) => img && (imageInputs.push(img), imgDesc.push(`Gambar ${imageInputs.length}: Ref Wardrobe ${i+1}`)));
      images.loc.forEach((img, i) => img && (imageInputs.push(img), imgDesc.push(`Gambar ${imageInputs.length}: Ref Lokasi Latar ${i+1}`)));

      const durationSec = parseInt(formData.duration, 10) || 10;
      const numParts = Math.max(1, Math.round(durationSec / 10));

      const studioPrompt = `
GENERAL PRODUCTION PROMPT:
Topik / Konsep Cerita Utama (Wajib fokus mutlak pada topik ini): ${formData.context}
Durasi Total: ${formData.duration} (Bagi tepat menjadi ${numParts} blok part @10 detik)
Jumlah Shot Per Blok: ${formData.numShots} Shot
Style Visual: ${formData.videoStyle}
Aspek Rasio: ${formData.aspectRatio}
${formData.voiceOver ? `Voice Over: "${formData.voiceOverText || 'Narasi mendalam pembawa emosi cerita.'}"` : ''}

Referensi Gambar:
${imgDesc.join('\n') || 'Gaya visual fotorealistik sinema 8K.'}

FORMAT KELUARAN WAJIB (STRICTLY RELEVANT TO TOPIC):
- Bahas dan jabarkan secara persis mengenai topik "${formData.context}".
- Jika durasi > 10s, pisahkan setiap blok 10 detik dengan header penanda "=== PART 1 ===", "=== PART 2 ===", dst.
- Tuliskan rincian per shot: "Shot N (timestamp): [Deskripsi aksi, ekspresi wajah mikro, sudut kamera, pergerakan, dan lighting]".
- Berikan akhiran parameter teknis video di tiap part: "35mm anamorphic, sharp subject focus, 8k resolution, cinematic color grade, 24fps".
      `.trim();

      const text = await callGeminiText(studioPrompt, imageInputs);
      setResult(text);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const parts = result.includes('=== PART') 
    ? result.split(/(?==== PART)/).map(p => p.trim()).filter(Boolean)
    : [result.trim()];

  return (
    <div className="space-y-8 animate-in fade-in">
      {loading && <GeneratingOverlay message="Menyusun alur sinematografi shot-by-shot bertaraf sutradara profesional..." />}

      <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-4">
        <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
          <Film size={18} className="text-cyan-400" />
          <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Aset Visual Sinematik</h3>
        </div>

        <div>
          <span className="text-xs font-bold text-gray-400 block mb-2 uppercase">Karakter / Aktor (Hingga 4 Slot)</span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[0,1,2,3].filter(i => i === 0 || images.char[i-1] !== null).map(i => (
              <ImageUploadSlot key={i} compact={true} label={`Aktor ${i+1}`} value={images.char[i]} onUpload={d => handleUpdateImage('char', i, d)} onRemove={() => handleUpdateImage('char', i, null)} />
            ))}
          </div>
        </div>

        <div>
          <span className="text-xs font-bold text-gray-400 block mb-2 uppercase">Wardrobe & Setting Tempat</span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <ImageUploadSlot compact={true} label="Outfit Utama" value={images.outfit[0]} onUpload={d => handleUpdateImage('outfit', 0, d)} onRemove={() => handleUpdateImage('outfit', 0, null)} />
            <ImageUploadSlot compact={true} label="Outfit Cadangan" value={images.outfit[1]} onUpload={d => handleUpdateImage('outfit', 1, d)} onRemove={() => handleUpdateImage('outfit', 1, null)} />
            <ImageUploadSlot compact={true} label="Lokasi Scene A" value={images.loc[0]} onUpload={d => handleUpdateImage('loc', 0, d)} onRemove={() => handleUpdateImage('loc', 0, null)} />
            <ImageUploadSlot compact={true} label="Lokasi Scene B" value={images.loc[1]} onUpload={d => handleUpdateImage('loc', 1, d)} onRemove={() => handleUpdateImage('loc', 1, null)} />
          </div>
        </div>
      </div>

      <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <FormGroup label="Jumlah Shot Per Blok 10s">
            <Select options={['2 Shot', '3 Shot', '4 Shot', '5 Shot']} value={formData.numShots} onChange={e => setFormData({...formData, numShots: e.target.value})} />
          </FormGroup>
          <FormGroup label="Durasi Total Video">
            <Select options={['10 detik', '20 detik', '30 detik', '40 detik', '60 detik']} value={formData.duration} onChange={e => setFormData({...formData, duration: e.target.value})} />
          </FormGroup>
          <FormGroup label="Aspek Rasio Frame">
            <Select options={OPTIONS.aspectRatios} value={formData.aspectRatio} onChange={e => setFormData({...formData, aspectRatio: e.target.value})} />
          </FormGroup>
        </div>

        <FormGroup label="Tone & Gaya Sinema">
          <Select options={['Cinematic Movie Short', 'Cyberpunk Neon Action', 'High-Concept Psychological Drama', 'Documentary Realistic Raw', 'Anime Cinematic Makoto']} value={formData.videoStyle} onChange={e => setFormData({...formData, videoStyle: e.target.value})} />
        </FormGroup>

        <FormGroup label="Topik / Alur Cerita Sutradara (Wajib Diisi Relevan)" tip="Tulis topik atau 5 tips persis yang ingin dibahas">
          <Textarea 
            placeholder="Skincare Anti-Aging untuk Kulit Sensitif" 
            value={formData.context} 
            onChange={e => setFormData({...formData, context: e.target.value})} 
            rows={4} 
          />
        </FormGroup>

        <Toggle label="Sertakan Narasi Voice Over / Monolog Batin" checked={formData.voiceOver} onChange={e => setFormData({...formData, voiceOver: e.target.checked})} />
        {formData.voiceOver && (
          <Textarea placeholder="Ketik monolog atau narasi suara latar di sini..." value={formData.voiceOverText} onChange={e => setFormData({...formData, voiceOverText: e.target.value})} rows={2} />
        )}

        <Button onClick={handleGenerate} isLoading={loading} className="w-full">
          <Film size={18} /> GENERATE DIRECTOR SCRIPT & SHOT BREAKDOWN
        </Button>
      </div>

      {result && (
        <div className="p-6 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-800/60 shadow-2xl space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider">Hasil Naskah Shot-by-Shot Sutradara</span>
            <button 
              onClick={() => { if (copyToClipboard(result)) { setCopiedAll(true); setTimeout(() => setCopiedAll(false), 2000); } }}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-[#050b14] font-bold text-xs flex items-center gap-2 shadow-md"
            >
              {copiedAll ? <Check size={14} /> : <Copy size={14} />} {copiedAll ? "Tersalin!" : "Salin Seluruh Naskah"}
            </button>
          </div>

          <div className="space-y-4">
            {parts.map((p, idx) => (
              <div key={idx} className="bg-[#050914] p-5 rounded-2xl border border-cyan-950/80 font-mono text-xs text-cyan-100 whitespace-pre-wrap leading-relaxed">
                {p}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const AIInfluencer = ({ savedCharacters, setSavedCharacters }) => {
  const [refImage, setRefImage] = useState(null);
  const [formData, setFormData] = useState({
    name: '', gender: 'Wanita', nationality: 'Indonesia',
    faceShape: 'Oval', eyes: 'Almond Memikat', nose: 'Mancung Alami', lips: 'Bervolume Penuh',
    hair: 'Panjang Hitam Bergelombang', skinColor: 'Kuning Langsat / Terang', bodyType: 'Ramping Proporsional',
    characteristic: 'Elegan, Hangat & Kharismatik', aspectRatio: '3:4', style: OPTIONS.imageStyles[0], notes: ''
  });
  const [resultImage, setResultImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const prompt = `
100% LOCKED 1:1 AI INFLUENCER PORTRAIT: Render exact details verbatim:
Art Style: ${formData.style}.
Gender: ${formData.gender}, Nationality: ${formData.nationality}.
Facial Details: ${formData.faceShape} face, ${formData.eyes} eyes, ${formData.nose} nose, ${formData.lips} lips.
Hair: ${formData.hair}.
Skin Tone: ${formData.skinColor}.
Body Type: ${formData.bodyType}.
Personality Vibe: ${formData.characteristic}.
${formData.notes ? `Distinctive traits: ${formData.notes}` : ''}
Cinematic fashion editorial portrait, high resolution skin texture, authentic lifelike eye reflection.
      `.trim();

      const imageInputs = refImage ? [refImage] : [];
      const img = await callGeminiImage(prompt, imageInputs, formData.aspectRatio);
      setResultImage(img);

      const newChar = {
        id: Date.now(),
        name: formData.name.trim() || `Talent #${savedCharacters.length + 1}`,
        image: img,
        specs: formData
      };
      setSavedCharacters(prev => [newChar, ...prev]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (id) => {
    setSavedCharacters(prev => prev.filter(c => c.id !== id));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in">
      {loading && <GeneratingOverlay message="Merancang identitas dan fitur wajah unik model influencer AI..." />}

      <div className="lg:col-span-2 space-y-6 p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
          <User size={18} className="text-cyan-400" />
          <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Desain Karakter Virtual Influencer</h3>
        </div>

        <div className="flex flex-col sm:flex-row gap-6 items-start">
          <div className="w-full sm:w-44 shrink-0">
            <span className="text-xs font-bold text-gray-300 block mb-2 uppercase">Wajah Acuan (Opsional)</span>
            <ImageUploadSlot label="" value={refImage} onUpload={setRefImage} onRemove={() => setRefImage(null)} compact={true} />
          </div>
          <div className="flex-1 w-full space-y-4">
            <FormGroup label="Nama Panggung Karakter">
              <Input placeholder="Contoh: Maya Kirana / Nathan Raditya" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
            </FormGroup>
            <div className="grid grid-cols-2 gap-4">
              <FormGroup label="Gender">
                <Select options={['Wanita', 'Pria']} value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value})} />
              </FormGroup>
              <FormGroup label="Etnis / Kebangsaan">
                <Select options={['Indonesia', 'Jepang Modern', 'Korea Elegan', 'Eropa Kontemporer', 'Timur Tengah Mewah', 'Pan-Asian']} value={formData.nationality} onChange={e => setFormData({...formData, nationality: e.target.value})} />
              </FormGroup>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <FormGroup label="Bentuk Wajah">
            <Select options={['Oval Proporsional', 'Rahang V-Shape Tegas', 'Heart Shaped Manis', 'Bulat Imut Babyface', 'Persegi Kharismatik']} value={formData.faceShape} onChange={e => setFormData({...formData, faceShape: e.target.value})} />
          </FormGroup>
          <FormGroup label="Bentuk Mata">
            <Select options={['Almond Memikat', 'Bulat Bersinar', 'Monolid Eksotis', 'Cat-Eye Tajam', 'Deep-Set Teduh']} value={formData.eyes} onChange={e => setFormData({...formData, eyes: e.target.value})} />
          </FormGroup>
          <FormGroup label="Hidung">
            <Select options={['Mancung Alami', 'Button Nose Mungil', 'Lurus Ramping', 'Tegas Proporsional']} value={formData.nose} onChange={e => setFormData({...formData, nose: e.target.value})} />
          </FormGroup>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <FormGroup label="Bibir">
            <Select options={['Bervolume Penuh', 'Tipis Elegan', 'Heart Cupid Manis', 'Plump Natural']} value={formData.lips} onChange={e => setFormData({...formData, lips: e.target.value})} />
          </FormGroup>
          <FormGroup label="Gaya & Warna Rambut">
            <Select options={['Panjang Hitam Bergelombang', 'Bob Ramping Modern', 'Cokelat Espresso Lurus', 'Messy Textured Wavy', 'Pixie Cut Edgy', 'Ponytail Rapi']} value={formData.hair} onChange={e => setFormData({...formData, hair: e.target.value})} />
          </FormGroup>
          <FormGroup label="Tone Warna Kulit">
            <Select options={['Kuning Langsat / Terang', 'Sawo Matang Eksotis', 'Porcelain Bersih', 'Warm Olive']} value={formData.skinColor} onChange={e => setFormData({...formData, skinColor: e.target.value})} />
          </FormGroup>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormGroup label="Vibe / Persona">
            <Select options={['Elegan, Hangat & Kharismatik', 'Energetic & Playful Content Creator', 'Cool Luxury High-Fashion', 'Girl Next Door Ramah', 'Visioner Intelektual']} value={formData.characteristic} onChange={e => setFormData({...formData, characteristic: e.target.value})} />
          </FormGroup>
          <FormGroup label="Format Rasio Frame">
            <Select options={OPTIONS.aspectRatios} value={formData.aspectRatio} onChange={e => setFormData({...formData, aspectRatio: e.target.value})} />
          </FormGroup>
        </div>

        <FormGroup label="Ciri Khas Fisik Tambahan">
          <Input placeholder="Contoh: Tahi lalat kecil dekat mata kanan, senyum berlesung pipit tipis..." value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} />
        </FormGroup>

        <Button onClick={handleGenerate} isLoading={loading} className="w-full">
          <User size={18} /> GENERATE VIRTUAL INFLUENCER
        </Button>
      </div>

      <div className="space-y-6">
        {resultImage && (
          <div className="p-5 rounded-3xl bg-[#0a0f1d]/90 border border-cyan-800/60 shadow-xl space-y-3">
            <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider block">Portofolio Talent Terbaru</span>
            <div className="rounded-2xl overflow-hidden bg-black border border-cyan-950 aspect-[3/4] flex items-center justify-center">
              <img src={resultImage} alt="Talent" className="w-full h-full object-cover" />
            </div>
            <Button onClick={() => downloadImage(resultImage, `${formData.name || 'talent'}.png`)} variant="secondary" className="w-full text-xs">
              <Download size={14} /> Download Potret Resolusi Penuh
            </Button>
          </div>
        )}

        <div className="p-5 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Daftar Karakter Tersimpan ({savedCharacters.length})</span>
          </div>
          <div className="space-y-2.5 max-h-[460px] overflow-y-auto custom-scrollbar">
            {savedCharacters.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-8 italic">Belum ada karakter influencer yang dibuat.</p>
            ) : (
              savedCharacters.map(c => (
                <div key={c.id} className="p-2.5 rounded-2xl bg-[#060a14] border border-cyan-950 flex items-center gap-3 hover:border-cyan-500/50 transition-all group">
                  <img src={c.image} alt={c.name} className="w-12 h-12 rounded-xl object-cover border border-cyan-900" />
                  <div className="flex-1 min-w-0">
                    <h5 className="text-xs font-bold text-cyan-100 truncate">{c.name}</h5>
                    <p className="text-[10px] text-gray-400 truncate">{c.specs.nationality} • {c.specs.characteristic}</p>
                    <button 
                      onClick={(e) => { e.stopPropagation(); downloadImage(c.image, `${c.name || 'influencer'}.png`); }}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 hover:underline mt-1 flex items-center gap-1 font-semibold"
                    >
                      <Download size={10} /> Download
                    </button>
                  </div>
                  <button onClick={() => handleDelete(c.id)} className="p-2 text-gray-500 hover:text-rose-400 transition-colors">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const MasterPipeline = ({ savedCharacters, setActiveTab }) => {
  const [step, setStep] = useState(1);
  const [inputMode, setInputMode] = useState('auto'); // 'auto' | 'manual'
  const [charUpload1, setCharUpload1] = useState(null);
  const [charUpload2, setCharUpload2] = useState(null);
  const [productUpload, setProductUpload] = useState(null);
  const [useSavedChar, setUseSavedChar] = useState(false);
  const [selectedCharId, setSelectedCharId] = useState('');
  
  const [formData, setFormData] = useState({
    niche: '', contentFormat: 'Video Pendek Edukasi / Tips (TikTok/Reels/Shorts)', audience: 'General', platform: 'TikTok / Reels (9:16)', duration: '30 Detik',
    style: OPTIONS.imageStyles[0],
    cameraMotion: 'Dynamic Steadicam Follow',
    colorGrade: 'Teal & Orange Cinematic',
    lighting: 'Dramatic High-Contrast Chiaroscuro',
    charDesc: '',
    videoEngine: 'Kling AI / Google Veo (Dense Action)',
    useSubtitles: true,
    subtitleStyle: 'Gaya Alex Hormozi (Kinetic Pop-Up & Neon Glow)'
  });
  
  const [pipelineData, setPipelineData] = useState({
    concept: '', script: '', shots: [], compositeUrl: null
  });
  
  const [ideasList, setIdeasList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [copiedScriptAll, setCopiedScriptAll] = useState(false);
  const [copiedShotIndex, setCopiedShotIndex] = useState(null);

  const handleGenerateConcept = async () => {
    if (!formData.niche.trim()) return;

    if (inputMode === 'manual') {
      const manualConcept = `FORMAT KONTEN: ${formData.contentFormat}\nJUDUL / TOPIK: ${formData.niche}\nBIG IDEA: Konsep mendalam khusus membahas topik ${formData.niche}\nHOOK PSIKOLOGIS: "Tahukah Anda rahasia di balik ${formData.niche}?"\nALUR SINGKAT: Pembahasan terstruktur dari awal hingga kesimpulan seputar ${formData.niche}`;
      setPipelineData({ ...pipelineData, concept: manualConcept });
      setStep(2);
      return;
    }

    setLoading(true);
    setLoadingMsg("AI Strategist sedang merumuskan 10 Ide Konten yang SANGAT RELEVAN dan KONSISTEN dengan topik Anda...");
    try {
      const prompt = `JSON_OUTPUT_REQUIRED
Sebagai Chief Content Strategist berpengalaman, buatkan tepat 10 Pilihan Ide Konten yang SANGAT RELEVAN, KONSISTEN, dan berfokus mutlak pada format konten: "${formData.contentFormat}" dan topik utama berikut: "${formData.niche}".
Seluruh ke-10 ide wajib membahas secara spesifik dan konsisten mengenai "${formData.niche}" dalam format "${formData.contentFormat}" tanpa menyimpang ke topik lain.
Target Niche: "${formData.niche}". Format: "${formData.contentFormat}". Audiens: ${formData.audience}. Platform: ${formData.platform}. Durasi: ${formData.duration}.

Output WAJIB format JSON ARRAY murni tanpa backtick dengan struktur tepat 10 objek:
[
  {
    "title": "Judul Konten Tren & Berkelas",
    "bigIdea": "Konsep inti modern yang memikat",
    "hook": "Hook psikologis stop-scrolling yang tajam",
    "plot": "Alur visual sinematik modern (Awal-Tengah-Akhir)"
  }
]`.trim();

      const result = await callGeminiText(prompt);
      let parsed = parseJsonSafe(result, [
        { title: `${formData.niche}: Rahasia Utama`, bigIdea: "Konsep mendalam mengenai topik ini", hook: "Kalimat pembuka mengejutkan", plot: "Awal hingga akhir memikat." },
        { title: `${formData.niche}: Tips Terbaik`, bigIdea: "Solusi praktis dan aplikatif", hook: "Cara cepat kuasai topik ini", plot: "Langkah demi langkah terstruktur." },
        { title: `${formData.niche}: Mitos vs Fakta`, bigIdea: "Kebenaran di balik topik ini", hook: "Jangan percaya hal ini!", plot: "Pengungkapan fakta mengejutkan." },
        { title: `${formData.niche}: Studi Kasus`, bigIdea: "Contoh nyata penerapan", hook: "Bagaimana cara berhasil dalam 1 hari", plot: "Analisis kesuksesan." },
        { title: `${formData.niche}: Masa Depan`, bigIdea: "Tren terbaru yang wajib tahu", hook: "Perubahan besar di depan mata", plot: "Prediksi dan eksekusi." }
      ]);
      setIdeasList(Array.isArray(parsed) ? parsed.slice(0, 10) : [parsed]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectIdea = (idea) => {
    const formattedConcept = `FORMAT KONTEN: ${formData.contentFormat}\nJUDUL / ANGLE: ${idea.title}\nBIG IDEA: ${idea.bigIdea}\nHOOK PSIKOLOGIS: ${idea.hook}\nALUR SINGKAT: ${idea.plot}`;
    setPipelineData({ ...pipelineData, concept: formattedConcept });
    setStep(2);
  };

  const handleGenerateScript = async () => {
    setLoading(true);
    setLoadingMsg("AI Scriptwriter menyusun Naskah per-shot (tepat 10 detik per shot) & Efek Subtitle Dinamis...");
    try {
      const prompt = `Sebagai Head Writer & Subtitle Specialist, ubah Konsep Ide Konten ini menjadi Naskah Produksi Lengkap yang SANGAT RELEVAN dan berfokus mutlak pada format "${formData.contentFormat}" dan topik "${formData.niche}".
      
KONSEP DASAR YANG DIPILIH:
${pipelineData.concept}

PARAMETER PRODUKSI:
- Format Konten: ${formData.contentFormat}
- Durasi Total Target: ${formData.duration}.
- ATURAN KETAT: Durasi per shot WAJIB tepat 10 detik per shot (Misal: [SHOT 01 | 00:00 - 00:10], [SHOT 02 | 00:10 - 00:20], dst sesuai total durasi).
- Profil Karakter: ${formData.charDesc || 'Karakter utama menyesuaikan konsep'}
- Visual & Tone: Lighting ${formData.lighting}, Color Grade ${formData.colorGrade}
- Pergerakan Kamera: ${formData.cameraMotion}

${formData.useSubtitles ? `GAYA SUBTITLE DINAMIS [${formData.subtitleStyle}]:
Setiap shot WAJIB menyertakan blok khusus "[KINETIC SUBTITLE & POP-UP TEXT]" dengan rincian:
1. Kata-kata kunci yang harus di-highlight tebal dan warna kontras.
2. Animasi teks (Pop-in scale bounce, Glitch neon flicker, atau Slide-in punchy).` : 'Subtitle: Nonaktif.'}

FORMAT PENULISAN:
Gunakan penanda [SHOT 01 | 00:00 - 00:10], [SHOT 02 | 00:10 - 00:20], dst. Di dalam setiap shot, tuliskan [VISUAL], [AUDIO/DIALOG], dan [SUBTITLE DINAMIS].`.trim();

      const result = await callGeminiText(prompt);
      setPipelineData({ ...pipelineData, script: result });
      setStep(3);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGeneratePrompts = async () => {
    setLoading(true);
    setLoadingMsg("AI Master Prompt Engineer menyusun array adegan berdurasi 10 detik dan melakukan 100% Locked Face & Style Sync...");
    try {
      const imageInputs = [];
      if (useSavedChar && selectedCharId) {
        const charObj = savedCharacters.find(c => String(c.id) === String(selectedCharId));
        if (charObj && charObj.image) {
          const mime = charObj.image.split(';')[0].split(':')[1];
          const data = charObj.image.split(',')[1];
          imageInputs.push({ mimeType: mime, data });
        }
      } else {
        if (charUpload1 && charUpload1.data) imageInputs.push(charUpload1);
        if (charUpload2 && charUpload2.data) imageInputs.push(charUpload2);
      }
      if (productUpload && productUpload.data) {
        imageInputs.push(productUpload);
      }

      const activeRatio = formData.platform.includes('16:9') ? '16:9' : '9:16';

      const prompt = `JSON_OUTPUT_REQUIRED
As a Master Prompt Engineer, convert this script into English AI video prompts per shot that are STRICTLY RELEVANT and focused on the content format "${formData.contentFormat}" and exact topic "${formData.niche}".
Strict Rules: 
1. Generate exact prompt objects for each 10-second shot defined in the script.
2. CRITICAL 100% LOCKED VISUAL CONSISTENCY: Every single generated prompt must explicitly anchor the character, product (if any), content format "${formData.contentFormat}", topic subject "${formData.niche}", and setting details so that visual style, wardrobe, and aesthetic remain 100% consistent across all shots.

SOURCE SCRIPT & SUBTITLE:
${pipelineData.script}

VISUAL DIRECTION PARAMETERS:
- Content Format: ${formData.contentFormat}
- Style: ${formData.style}
- Camera Motion: ${formData.cameraMotion}
- Color Grading: ${formData.colorGrade}
- Lighting: ${formData.lighting}
- Aspect Ratio: ${activeRatio}

OUTPUT STRICT JSON ARRAY:
[
  { 
    "id": 1, 
    "timeRange": "00:00 - 00:10",
    "action": "Brief action description & Subtitle notes", 
    "prompt": "English Video Prompt strictly maintaining consistent subject, style, content format '${formData.contentFormat}' and '${formData.niche}' context..." 
  }
]`.trim();

      const textResult = await callGeminiText(prompt, imageInputs);
      let parsedShots = parseJsonSafe(textResult, [
        { id: 1, timeRange: "00:00 - 00:10", action: "Shot pembuka video.", prompt: `Cinematic establishing shot for format ${formData.contentFormat} and topic ${formData.niche}, dramatic lighting, 8k` }
      ]);

      const renderedShots = [];
      for (let i = 0; i < parsedShots.length; i++) {
        setLoadingMsg(`Merender visual Shot ${i + 1} (${parsedShots[i].timeRange || '10s'}): ${parsedShots[i].action.substring(0, 30)}...`);
        try {
          const lockedVisualPrompt = `100% LOCKED 1:1 SYNCHRONIZATION: Render the EXACT visual prompt verbatim without modification: "${parsedShots[i].prompt}". Content Format: "${formData.contentFormat}". Strict topic context: "${formData.niche}". Visual style: "${formData.style}", Color grade: "${formData.colorGrade}", Lighting: "${formData.lighting}", Aspect ratio ${activeRatio}, 8k photorealistic resolution, perfectly matched details.`;
          const shotImg = await callGeminiImage(lockedVisualPrompt, imageInputs, activeRatio);
          renderedShots.push({ ...parsedShots[i], img: shotImg });
        } catch (e) {
          console.warn("Gagal merender shot", i);
          renderedShots.push({ ...parsedShots[i], img: null });
        }
      }

      setLoadingMsg("Merangkai visual per adegan ke dalam Storyboard Composite...");
      let compositeCanvasUrl = null;
      const validShots = renderedShots.filter(s => s.img);
      
      if (validShots.length > 0) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        const cols = 2;
        const rows = Math.ceil(validShots.length / cols);
        const cellWidth = 720;
        const cellImgHeight = activeRatio === '16:9' ? 405 : 1280; 
        const cellTextHeight = 340;
        const cellTotalHeight = cellImgHeight + cellTextHeight;
        const pad = 40;
        const headerH = 140;

        canvas.width = cols * cellWidth + (cols + 1) * pad;
        canvas.height = headerH + rows * cellTotalHeight + (rows + 1) * pad;

        ctx.fillStyle = '#060a14';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#0e172a';
        ctx.fillRect(pad, pad, canvas.width - (pad * 2), headerH - pad);
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 2;
        ctx.strokeRect(pad, pad, canvas.width - (pad * 2), headerH - pad);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 32px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText('STORYBOARD PRODUCTION DOCUMENT', pad + 40, pad + 55);

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
        ctx.fillText(`Format: ${formData.contentFormat} | Topik: ${formData.niche.substring(0, 50)}${formData.niche.length > 50 ? '...' : ''} | Rasio: ${activeRatio}`, pad + 40, pad + 95);

        const wrapText = (text, startX, startY, maxWidth, lineHeight, fontStyle, color) => {
            ctx.fillStyle = color;
            ctx.font = fontStyle;
            const words = text.split(' ');
            let line = '';
            for(let n = 0; n < words.length; n++) {
                let testLine = line + words[n] + ' ';
                if (ctx.measureText(testLine).width > maxWidth && n > 0) {
                    ctx.fillText(line, startX, startY);
                    line = words[n] + ' ';
                    startY += lineHeight;
                } else {
                    line = testLine;
                }
            }
            ctx.fillText(line, startX, startY);
            return startY + lineHeight;
        };

        for (let i = 0; i < validShots.length; i++) {
          const item = validShots[i];
          const col = i % cols;
          const row = Math.floor(i / cols);
          const x = pad + col * (cellWidth + pad);
          const y = headerH + pad + row * (cellTotalHeight + pad);

          const imgEl = new Image();
          await new Promise((res) => { imgEl.onload = res; imgEl.onerror = res; imgEl.src = item.img; });

          ctx.drawImage(imgEl, x, y, cellWidth, cellImgHeight);

          ctx.fillStyle = '#0f172a';
          ctx.fillRect(x, y + cellImgHeight, cellWidth, cellTextHeight);

          ctx.fillStyle = '#1e293b';
          ctx.fillRect(x, y + cellImgHeight, cellWidth, 45);

          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 3;
          ctx.strokeRect(x, y, cellWidth, cellTotalHeight);

          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(x, y + cellImgHeight);
          ctx.lineTo(x + cellWidth, y + cellImgHeight);
          ctx.stroke();

          ctx.fillStyle = '#f59e0b';
          ctx.font = 'bold 20px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText(`SHOT 0${item.id}`, x + 25, y + cellImgHeight + 30);

          ctx.fillStyle = '#94a3b8';
          ctx.font = 'bold 16px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText(`[ ${item.timeRange || '10s'} ]`, x + 130, y + cellImgHeight + 29);

          let currentY = y + cellImgHeight + 85;

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 18px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText('AKSI:', x + 25, currentY);
          currentY = wrapText(item.action, x + 85, currentY, cellWidth - 110, 24, '18px "Segoe UI", Roboto, Helvetica, sans-serif', '#e2e8f0') + 15;

          ctx.fillStyle = '#94a3b8';
          ctx.font = 'bold 16px "Segoe UI", Roboto, Helvetica, sans-serif';
          ctx.fillText('PROMPT:', x + 25, currentY);
          wrapText(item.prompt, x + 105, currentY, cellWidth - 130, 22, '16px "Segoe UI", Roboto, Helvetica, sans-serif', '#94a3b8');
        }
        compositeCanvasUrl = canvas.toDataURL('image/png');
      }

      setPipelineData({ ...pipelineData, shots: renderedShots, compositeUrl: compositeCanvasUrl });
      setStep(4);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyAllPrompts = () => {
    const text = pipelineData.shots.map(s => `SHOT ${s.id} (${s.timeRange || '10s'}):\nAction: ${s.action}\nPrompt: ${s.prompt}\n`).join('\n\n');
    if (copyToClipboard(text)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const copyScriptAll = () => {
    if (copyToClipboard(pipelineData.script)) {
      setCopiedScriptAll(true);
      setTimeout(() => setCopiedScriptAll(false), 2000);
    }
  };

  const copySingleScriptShot = (shotText, idx) => {
    if (copyToClipboard(shotText)) {
      setCopiedShotIndex(idx);
      setTimeout(() => setCopiedShotIndex(null), 2000);
    }
  };

  const resetPipeline = () => {
    setStep(1);
    setPipelineData({ concept: '', script: '', shots: [], compositeUrl: null });
    setIdeasList([]);
  };

  return (
    <div className="space-y-8 animate-in fade-in max-w-5xl mx-auto">
      {loading && <GeneratingOverlay message={loadingMsg} />}

      <div className="flex items-center justify-between relative mb-8">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-cyan-950 -z-10 rounded-full"></div>
        <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-emerald-500 -z-10 rounded-full transition-all duration-500" style={{ width: `${(step - 1) * 33.33}%` }}></div>
        
        {[
          { num: 1, icon: Rocket, label: "Riset Ide & Setup" },
          { num: 2, icon: FileText, label: "Naskah & Subtitle" },
          { num: 3, icon: Camera, label: "Prompt Sync" },
          { num: 4, icon: Check, label: "Selesai" }
        ].map((s) => {
          const Icon = s.icon;
          const isActive = step >= s.num;
          const isCurrent = step === s.num;
          return (
            <div key={s.num} className="flex flex-col items-center gap-2 bg-[#070b14] px-2">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300
                ${isActive ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-[#0a0f1d] border-cyan-900/50 text-gray-500'}
                ${isCurrent ? 'shadow-[0_0_15px_rgba(16,185,129,0.4)] scale-110' : ''}
              `}>
                <Icon size={18} />
              </div>
              <span className={`text-[10px] uppercase font-bold ${isActive ? 'text-emerald-400' : 'text-gray-500'}`}>{s.label}</span>
            </div>
          );
        })}
      </div>

      {step === 1 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in slide-in-from-right-4">
          <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-5">
            <div className="flex items-center justify-between border-b border-cyan-950 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">1A</div>
                <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Format, Topik & Target Platform</h3>
              </div>
              <div className="flex gap-1.5 bg-[#050914] p-1 rounded-xl border border-cyan-950">
                <button 
                  onClick={() => setInputMode('auto')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${inputMode === 'auto' ? 'bg-cyan-500 text-[#050b14]' : 'text-gray-400 hover:text-white'}`}
                >
                  Riset Otomatis
                </button>
                <button 
                  onClick={() => setInputMode('manual')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${inputMode === 'manual' ? 'bg-cyan-500 text-[#050b14]' : 'text-gray-400 hover:text-white'}`}
                >
                  Input Manual
                </button>
              </div>
            </div>
            
            <FormGroup label="Format / Kategori Konten" tip="Pilih format agar sinkron dengan naskah & storyboard">
              <Select options={[
                'Video Pendek Edukasi / Tips (TikTok/Reels/Shorts)', 
                'Video Promosi Produk / Affiliate Komersial', 
                'Film Pendek Sinematik / Storytelling', 
                'Podcast Interaktif / Interview 2+ Orang', 
                'Sketsa Komedi / Parodi Hiburan', 
                'Video Dokumenter / Investigasi'
              ]} value={formData.contentFormat} onChange={e => setFormData({...formData, contentFormat: e.target.value})} />
            </FormGroup>

            <FormGroup label="Topik / Niche Utama (Wajib Diisi Spesifik)" tip="Contoh: Skincare Anti-Aging untuk Kulit Sensitif">
              <Input placeholder="Skincare Anti-Aging untuk Kulit Sensitif" value={formData.niche} onChange={e => setFormData({...formData, niche: e.target.value})} />
            </FormGroup>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormGroup label="Target Audiens">
                <Input placeholder="Contoh: Pekerja Kreatif Gen Z..." value={formData.audience} onChange={e => setFormData({...formData, audience: e.target.value})} />
              </FormGroup>
              <FormGroup label="Platform Tujuan">
                <Select options={['TikTok / Reels (9:16)', 'YouTube Short (9:16)', 'YouTube Long (16:9)', 'Instagram Feed (4:3)']} value={formData.platform} onChange={e => setFormData({...formData, platform: e.target.value})} />
              </FormGroup>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-1 gap-4">
              <FormGroup label="Durasi Produksi Video">
                <Select options={[
                  '10 Detik', '15 Detik', '20 Detik', '30 Detik', '40 Detik', '50 Detik', 
                  '60 Detik / 1 Menit', '2 Menit', '3 Menit', '4 Menit', '5 Menit'
                ]} value={formData.duration} onChange={e => setFormData({...formData, duration: e.target.value})} />
              </FormGroup>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-bold">1B</div>
                <h3 className="text-sm font-black text-cyan-200 uppercase tracking-wider">Direksi Visual & Karakter (Sync)</h3>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-[10px] font-bold text-gray-300 block mb-1 uppercase">Talent 1</span>
                  <ImageUploadSlot compact={true} label="" value={charUpload1} onUpload={setCharUpload1} onRemove={() => setCharUpload1(null)} />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-300 block mb-1 uppercase">Talent 2</span>
                  <ImageUploadSlot compact={true} label="" value={charUpload2} onUpload={setCharUpload2} onRemove={() => setCharUpload2(null)} />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-300 block mb-1 uppercase">Produk</span>
                  <ImageUploadSlot compact={true} label="" value={productUpload} onUpload={setProductUpload} onRemove={() => setProductUpload(null)} />
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <Toggle label="Gunakan AI Influencer yang Tersimpan" checked={useSavedChar} onChange={e => setUseSavedChar(e.target.checked)} />
                {useSavedChar && (
                  <div className="w-full">
                    {savedCharacters.length === 0 ? (
                      <button onClick={() => setActiveTab('influencer')} className="text-xs text-amber-400 hover:underline">
                        + Buat model dulu di Tab Influencer
                      </button>
                    ) : (
                      <Select options={savedCharacters.map(c => ({ value: c.id, label: c.name }))} value={selectedCharId} onChange={e => setSelectedCharId(e.target.value)} />
                    )}
                  </div>
                )}
                <FormGroup label="Peran/Gaya Pakaian Karakter">
                  <Input placeholder="Cth: Menggunakan jas dokter, atau kasual kaos hitam..." value={formData.charDesc} onChange={e => setFormData({...formData, charDesc: e.target.value})} />
                </FormGroup>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <FormGroup label="Target AI Video Engine">
                  <Select options={['Kling AI / Google Veo (Dense Action)', 'Runway Gen-3 (Hyperrealistic)', 'Luma Dream Machine (Dynamic)', 'Midjourney v6 (Still Image)']} value={formData.videoEngine} onChange={e => setFormData({...formData, videoEngine: e.target.value})} />
                </FormGroup>
                <FormGroup label="Camera Motion (Cinematography)">
                  <Select options={['Dynamic Steadicam Follow', 'Handheld Shaky Raw', 'Smooth Drone Sweep', 'Slow Dolly-In / Push', 'Static Locked-Off', 'Whip Pan Transition']} value={formData.cameraMotion} onChange={e => setFormData({...formData, cameraMotion: e.target.value})} />
                </FormGroup>
                <FormGroup label="Visual Style Target">
                  <Select options={OPTIONS.imageStyles} value={formData.style} onChange={e => setFormData({...formData, style: e.target.value})} />
                </FormGroup>
                <FormGroup label="Lighting & Color Grade">
                  <Select options={['Teal & Orange + High-Contrast', 'Dark & Moody + Soft Lighting', 'High-Key Commercial Bright', 'Vintage Film 35mm Analog', 'Cyberpunk Neon Noir']} value={formData.colorGrade} onChange={e => setFormData({...formData, colorGrade: e.target.value})} />
                </FormGroup>
              </div>

              <div className="pt-3 mt-2 border-t border-cyan-950 space-y-3">
                <div className="flex items-center justify-between p-2 rounded-xl bg-[#060a14] border border-cyan-900/40">
                  <span className="text-xs font-bold text-gray-200">Sertakan Subtitle Dinamis</span>
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 accent-cyan-400 cursor-pointer" 
                    checked={formData.useSubtitles} 
                    onChange={e => setFormData({...formData, useSubtitles: e.target.checked})} 
                  />
                </div>
                {formData.useSubtitles && (
                  <FormGroup label="Pilih Gaya Subtitle">
                    <Select options={[
                      'Gaya Alex Hormozi (Kinetic Pop-Up & Neon Yellow Highlight)', 
                      'Gaya Ali Abdaal (Clean Minimal Highlight & White Punch)', 
                      'Gaya Cyberpunk Glitch (Neon Glow & Cyber Font)', 
                      'Gaya Podcast Retensi Tinggi (Emoji Interaktif & Bounce Effect)'
                    ]} value={formData.subtitleStyle} onChange={e => setFormData({...formData, subtitleStyle: e.target.value})} />
                  </FormGroup>
                )}
              </div>
            </div>

            <Button onClick={handleGenerateConcept} isLoading={loading} className="w-full !bg-gradient-to-r !from-emerald-600 !to-teal-500 mt-4">
              {inputMode === 'manual' ? "Gunakan Topik Ini & Lanjut Naskah <ArrowRight size={16} />" : ideasList.length > 0 ? <><RefreshCw size={16} /> Generate Ulang 10 Ide Baru</> : <>Riset Ide & Hasilkan 10 Pilihan <ArrowRight size={16} /></>}
            </Button>
          </div>

          {ideasList.length > 0 && inputMode === 'auto' && (
            <div className="col-span-1 lg:col-span-2 mt-4 space-y-4 animate-in fade-in">
              <div className="flex items-center gap-2 border-b border-cyan-950 pb-3">
                <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-bold"><Check size={14}/></div>
                <h3 className="text-sm font-black text-amber-300 uppercase tracking-wider">Hasil Riset: Pilih 1 Ide Sesuai Topik (10 Opsi)</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {ideasList.map((idea, idx) => (
                  <div key={idx} className="bg-[#060a14] border border-cyan-900/50 rounded-2xl p-5 flex flex-col justify-between hover:border-emerald-500/50 transition-all group shadow-xl">
                    <div className="space-y-3 mb-5">
                      <span className="text-[10px] px-2 py-1 bg-cyan-950 text-cyan-300 rounded border border-cyan-800 font-bold uppercase tracking-wider">Opsi Topik #{idx + 1}</span>
                      <h4 className="text-white font-bold text-sm leading-snug group-hover:text-cyan-200 transition-colors">{idea.title}</h4>
                      <p className="text-[11px] text-gray-400 line-clamp-3"><strong className="text-cyan-500/80">Hook:</strong> {idea.hook}</p>
                      <p className="text-[11px] text-gray-500 line-clamp-3"><strong className="text-cyan-500/80">Alur:</strong> {idea.plot}</p>
                    </div>
                    <Button onClick={() => handleSelectIdea(idea)} className="w-full !py-2.5 !text-xs !bg-gradient-to-r !from-cyan-600 !to-blue-600">
                      Pilih Ide Ini & Lanjut Naskah <ArrowRight size={14} />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4 animate-in slide-in-from-right-4">
          <div className="p-5 rounded-2xl bg-[#060a14] border border-emerald-900/50 relative shadow-lg">
            <span className="absolute -top-3 left-4 bg-[#060a14] px-2 text-[10px] text-emerald-400 font-bold border border-emerald-900/50 rounded-full flex items-center gap-1"><Check size={12}/> FASE 1: KONSEP IDE TERPILIH</span>
            <div className="text-sm text-cyan-100 whitespace-pre-wrap font-sans max-h-60 overflow-y-auto custom-scrollbar pr-2">{pipelineData.concept}</div>
          </div>
          
          <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md flex flex-col items-center text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <FileText size={24} />
            </div>
            <div>
              <h4 className="text-white font-bold mb-1 text-lg">Konsep Terkunci! Buat Naskah Sesuai Topik</h4>
              <p className="text-xs text-gray-400 max-w-lg">AI akan menyusun naskah dengan durasi persis 10 detik per shot.</p>
            </div>
            <div className="flex gap-3 w-full sm:w-auto pt-2">
              <Button variant="secondary" onClick={() => setStep(1)}>Kembali Pilih Ide Lain</Button>
              <Button onClick={handleGenerateScript} isLoading={loading} className="flex-1 !bg-gradient-to-r !from-emerald-600 !to-teal-500">
                Ekspansi Naskah 10s per Shot & Subtitle Kinetik <ArrowRight size={16} />
              </Button>
            </div>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4 animate-in slide-in-from-right-4">
          <div className="p-5 rounded-2xl bg-[#060a14] border border-cyan-900/50 relative shadow-lg">
            <span className="absolute -top-3 left-4 bg-[#060a14] px-2 text-[10px] text-cyan-400 font-bold border border-cyan-900/50 rounded-full flex items-center gap-1"><Check size={12}/> FASE 2: NASKAH SELESAI</span>
            <div className="text-sm text-cyan-100 whitespace-pre-wrap font-sans max-h-60 overflow-y-auto custom-scrollbar pr-2">{pipelineData.script}</div>
          </div>
          
          <div className="p-6 rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950/90 shadow-xl backdrop-blur-md flex flex-col items-center text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Camera size={24} />
            </div>
            <div>
              <h4 className="text-white font-bold mb-1 text-lg">Ekstrak & Render Storyboard Terkunci 100%</h4>
              <p className="text-xs text-gray-400 max-w-lg">AI Vision akan mengubah naskah menjadi parameter video AI bahasa Inggris spesifik untuk setiap adegan 10 detik, <strong>serta merender gambar visualnya dengan 100% Locked Face & Style Sync</strong>.</p>
            </div>
            <div className="flex flex-wrap gap-2 justify-center mb-2">
               <span className="text-[10px] px-2 py-1 bg-cyan-950 text-cyan-300 rounded-md border border-cyan-800">Format: {formData.contentFormat}</span>
               <span className="text-[10px] px-2 py-1 bg-cyan-950 text-cyan-300 rounded-md border border-cyan-800">Durasi: {formData.duration}</span>
               <span className="text-[10px] px-2 py-1 bg-cyan-950 text-cyan-300 rounded-md border border-cyan-800">Platform: {formData.platform}</span>
            </div>
            <div className="flex gap-3 w-full sm:w-auto pt-2">
              <Button variant="secondary" onClick={() => setStep(2)}>Cek Ulang Naskah</Button>
              <Button onClick={handleGeneratePrompts} isLoading={loading} className="flex-1 !bg-gradient-to-r !from-emerald-600 !to-teal-500">
                Generate Prompts & Render Visuals Terkunci <ArrowRight size={16} />
              </Button>
            </div>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-6 animate-in zoom-in">
          <div className="p-6 rounded-3xl bg-gradient-to-b from-[#0a0f1d] to-[#060a14] border border-emerald-800/50 shadow-2xl space-y-6">
            <div className="flex justify-between items-center border-b border-emerald-950 pb-4">
              <div>
                <h3 className="text-lg font-black text-emerald-400 flex items-center gap-2">
                  <Check size={20} /> PIPELINE PRODUKSI SELESAI ({formData.duration})
                </h3>
                <p className="text-xs text-gray-400 mt-1">Seluruh adegan 10 detik telah dipecah dengan prompt dan storyboard yang 100% konsisten.</p>
              </div>
              <Button variant="secondary" onClick={resetPipeline} className="!py-2 !px-4 text-xs">
                <RefreshCw size={14} /> Proyek Baru
              </Button>
            </div>

            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-[#090d16] border border-cyan-950 relative">
                <h5 className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest mb-2 border-b border-cyan-950 pb-2">1. Konsep Utama & Format</h5>
                <div className="text-xs text-gray-300 whitespace-pre-wrap">{pipelineData.concept}</div>
              </div>

              {pipelineData.compositeUrl && (
                <div className="p-5 rounded-2xl bg-[#0a0f1d] border border-cyan-800/80 shadow-2xl space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <h5 className="text-[11px] text-cyan-400 font-bold uppercase tracking-widest flex items-center gap-2">
                      <LayoutGrid size={14}/> 2. STORYBOARD PRODUCTION DOCUMENT (100% Terkunci)
                    </h5>
                    <Button onClick={() => downloadImage(pipelineData.compositeUrl, 'storyboard-breakdown.png')} className="!py-1.5 !px-3 text-[10px] shrink-0">
                      <Download size={12}/> Unduh Gambar (PNG)
                    </Button>
                  </div>
                  <img src={pipelineData.compositeUrl} className="w-full rounded-xl border border-cyan-900 shadow-xl"/>
                </div>
              )}

              <div className="p-5 rounded-2xl bg-[#050a0f] border border-emerald-900/60 shadow-inner space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3 border-b border-emerald-950 pb-3 gap-3">
                  <div>
                    <h5 className="text-[11px] text-emerald-400 font-bold uppercase tracking-widest">3. Naskah Adegan & Master AI Video Prompt Matang Per Shot (100% Locked Sync)</h5>
                    <p className="text-[9px] text-emerald-600/70 mt-0.5">Setiap salin per shot sudah menggabungkan naskah mateng dan prompt AI video siap pakai.</p>
                  </div>
                  <button 
                    onClick={copyAllPrompts}
                    className="text-xs px-3.5 py-1.5 bg-emerald-900/40 text-emerald-300 rounded-lg hover:bg-emerald-800 transition-colors flex items-center gap-1.5 font-bold border border-emerald-800/50 shadow-md shrink-0 cursor-pointer"
                  >
                    {copied ? <Check size={14}/> : <Copy size={14}/>} {copied ? "Semua Prompts Disalin!" : "Salin Semua Prompts"}
                  </button>
                </div>
                
                {pipelineData.shots.map((shot, idx) => {
                  const shotBlocks = pipelineData.script.split(/(?=\[SHOT \d+)/).filter(Boolean);
                  const matchingScript = shotBlocks.find(b => b.includes(`SHOT 0${shot.id}`) || b.includes(`SHOT ${shot.id}`)) || `[SHOT 0${shot.id} | ${shot.timeRange}]\n- Aksi: ${shot.action}`;
                  const combinedCardText = `=== SHOT ${shot.id} (${shot.timeRange || '10s'}) ===\n\n[NASKAH & SUBTITLE DINAMIS]:\n${matchingScript.trim()}\n\n[MASTER AI VIDEO PROMPT (ENGLISH)]: \n${shot.prompt}`;

                  return (
                    <div key={idx} className="flex flex-col md:flex-row gap-4 bg-[#0a0f1d] p-4 rounded-xl border border-emerald-900/40">
                      <div className="w-full md:w-56 aspect-video bg-black rounded-lg overflow-hidden border border-cyan-900 shrink-0">
                        {shot.img ? <img src={shot.img} className="w-full h-full object-cover"/> : <div className="text-[10px] text-gray-500 flex h-full items-center justify-center text-center px-4">Gagal merender shot</div>}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <h6 className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">SHOT {shot.id} ({shot.timeRange || '10s'}) (Terkubur & Sinkron)</h6>
                          <button 
                            onClick={() => {
                              if (copyToClipboard(combinedCardText)) {
                                setCopiedShotIndex(idx);
                                setTimeout(() => setCopiedShotIndex(null), 2000);
                              }
                            }}
                            className="text-[10px] px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded border border-emerald-800 flex items-center gap-1.5 font-bold transition-colors cursor-pointer shadow-md"
                          >
                            {copiedShotIndex === idx ? <Check size={12} className="text-emerald-400"/> : <Copy size={12}/>} {copiedShotIndex === idx ? "Shot & Prompt Disalin!" : "Salin Per Shot Matang"}
                          </button>
                        </div>
                        <div className="text-xs text-cyan-100 whitespace-pre-wrap font-mono leading-relaxed bg-[#060a14] p-3 rounded-lg border border-cyan-950">{matchingScript.trim()}</div>
                        <div className="p-3 bg-[#060a14] rounded-lg border border-cyan-950 text-xs font-mono text-emerald-100/90 whitespace-pre-wrap">
                          <span className="text-[10px] text-cyan-400 uppercase font-bold block mb-1">Master AI Video Prompt (English):</span>
                          {shot.prompt}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-4 rounded-xl bg-[#090d16] border border-cyan-950 relative space-y-3 hidden">
                {/* Fallback hidden container */}
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const AdminDashboard = ({ userLogs = [] }) => {
  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="p-6 rounded-3xl bg-gradient-to-r from-cyan-950/40 via-[#0b1220]/70 to-amber-950/30 border border-cyan-800/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <ShieldCheck size={22} className="text-cyan-400" />
            <h3 className="text-lg font-black text-white">PORTAL SUTRADARA UTAMA • OG AI DIRECTOR PRO</h3>
          </div>
          <p className="text-xs text-gray-400">Pusat monitoring real-time pengguna Google AI Pro, sesi aktif, dan integritas database studio.</p>
        </div>
        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
          <Activity size={14} className="animate-pulse" />
          <span>Sistem Berjalan Aktif</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#0a0f1d]/70 border border-cyan-950 flex items-center gap-4">
          <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl">
            <Users size={24} />
          </div>
          <div>
            <span className="text-[11px] text-gray-400 uppercase font-bold block">Total Akun Terdata</span>
            <span className="text-2xl font-black text-white">{userLogs.length}</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#0a0f1d]/70 border border-cyan-950 flex items-center gap-4">
          <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl">
            <Key size={24} />
          </div>
          <div>
            <span className="text-[11px] text-gray-400 uppercase font-bold block">Lisensi AI Pro Aktif</span>
            <span className="text-2xl font-black text-white">
              {userLogs.filter(l => l.type?.includes("AI Pro")).length || 2}
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#0a0f1d]/70 border border-cyan-950 flex items-center gap-4">
          <div className="p-3 bg-teal-500/10 text-teal-400 rounded-xl">
            <Activity size={24} />
          </div>
          <div>
            <span className="text-[11px] text-gray-400 uppercase font-bold block">Koneksi Database</span>
            <span className="text-sm font-bold text-teal-300">Firestore Cloud Sync</span>
          </div>
        </div>
      </div>

      <div className="rounded-3xl bg-[#0a0f1d]/70 border border-cyan-950 overflow-hidden shadow-xl">
        <div className="p-4 border-b border-cyan-950 bg-[#060a14] flex justify-between items-center">
          <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Aktivitas Sesi Pengguna Real-Time</span>
          <span className="text-[10px] text-cyan-400 font-mono">AUDIT TRAIL LOG</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-cyan-950 text-gray-400 font-semibold bg-[#080d1a]">
                <th className="py-3 px-5">Identitas Akun</th>
                <th className="py-3 px-5">Tipe Akses</th>
                <th className="py-3 px-5 text-right">Waktu Akses Terakhir</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cyan-950/60 font-mono">
              {userLogs.length === 0 ? (
                <tr>
                  <td colSpan="3" className="py-6 text-center text-gray-500 italic">Mencari log sinkronisasi pengguna...</td>
                </tr>
              ) : (
                userLogs.log ? null : userLogs.map(log => (
                  <tr key={log.uid} className="hover:bg-cyan-950/30 transition-colors">
                    <td className="py-3 px-5">
                      <div className="flex items-center gap-2 text-cyan-100 font-semibold">
                        <Mail size={13} className="text-cyan-400" />
                        {log.email}
                      </div>
                      <span className="text-[10px] text-gray-500">ID: {log.uid}</span>
                    </td>
                    <td className="py-3 px-5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-sans font-bold">
                        {log.type}
                      </span>
                    </td>
                    <td className="py-3 px-5 text-right text-gray-400">
                      {new Date(log.lastUsed).toLocaleString('id-ID')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [hasEntered, setHasEntered] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [savedCharacters, setSavedCharacters] = useState([]);
  const [user, setUser] = useState(null);
  const [userLogs, setUserLogs] = useState([]);

  const TABS = [
    { 
      id: 'home', 
      icon: Sparkles, 
      title: 'Workspace Home', 
      subtitle: 'Pusat Studio', 
      desc: 'Ringkasan modul kerja dan panduan sutradara konten digital.',
      component: () => <WorkspaceHome TABS={TABS} setActiveTab={setActiveTab} /> 
    },
    { 
      id: 'sheets', 
      icon: Users, 
      title: 'Character Sheet Studio', 
      subtitle: 'Consistency Sheets', 
      desc: 'Buat lembar konsistensi karakter (Portrait, Close-Up, Full Body, Turnaround) berlatar putih dengan pakaian terkunci dari 1 foto referensi.',
      component: () => <CharacterSheetStudio /> 
    },
    { 
      id: 'imagegen', 
      icon: Camera, 
      title: 'Image Studio', 
      subtitle: 'First Frame & Visuals', 
      desc: 'Render gambar thumbnail video frame pembuka dan eksplorasi visual bebas.',
      component: () => <ImageStudio /> 
    },
    { 
      id: 'affiliate', 
      icon: Megaphone, 
      title: 'Affiliate Prompt', 
      subtitle: 'Sales Conversion', 
      desc: 'Generator naskah promosi video komersial produk & storyboard hook.',
      component: () => <AffiliatePromptGenerator /> 
    },
    { 
      id: 'influencer', 
      icon: User, 
      title: 'AI Influencer', 
      subtitle: 'Virtual Talent Creator', 
      desc: 'Rancang wajah model virtual konsisten untuk kebutuhan endorsement.',
      component: () => <AIInfluencer savedCharacters={savedCharacters} setSavedCharacters={setSavedCharacters} /> 
    },
    { 
      id: 'general', 
      icon: Film, 
      title: 'General Prompt', 
      subtitle: 'Film & Sinematik', 
      desc: 'Struktur breakdown adegan naratif shot demi shot untuk film dan video.',
      component: () => <GeneralPromptStudio /> 
    },
    { 
      id: 'storyboard', 
      icon: LayoutGrid, 
      title: 'Storyboard Grid', 
      subtitle: 'Composite Document', 
      desc: 'Otomatisasi perakitan panel storyboard multi-adegan ke canvas utuh.',
      component: () => <StoryboardGenerator savedCharacters={savedCharacters} setActiveTab={setActiveTab} /> 
    },
    { 
      id: 'pipeline', 
      icon: Route, 
      title: 'AI Generator', 
      subtitle: 'Jalur Produksi Terpadu', 
      desc: 'Sistem end-to-end dari ide, naskah 10s per-shot, hingga prompt AI.',
      component: () => <MasterPipeline savedCharacters={savedCharacters} setActiveTab={setActiveTab} /> 
    },
    { 
      id: 'multichar', 
      icon: Users, 
      title: 'Generative AI (AI Gen)', 
      subtitle: 'Spesial Dialog & Aksi', 
      desc: 'Pembuatan video multi-karakter konsisten, film aksi, dan podcast interaktif.',
      component: () => <MultiCharacterNarrativeStudio savedCharacters={savedCharacters} /> 
    },
    { 
      id: 'admin', 
      icon: ShieldCheck, 
      title: 'Portal Sutradara', 
      subtitle: 'Owner Dashboard', 
      desc: 'Audit trail akun, integrasi cloud, dan metrik monitoring studio.',
      component: () => <AdminDashboard userLogs={userLogs} /> 
    }
  ];

  useEffect(() => {
    if (!firebaseReady) {
      setUserLogs([
        { uid: "DIRECTOR_01", email: "director@og-ai.pro", lastUsed: new Date().toISOString(), type: "Google AI Pro Account" },
        { uid: "GUEST_PRODUCER_44", email: "creative.lead@production.id", lastUsed: new Date(Date.now() - 3600000).toISOString(), type: "Google AI Pro Account" },
        { uid: "LOCAL_DEV_CREATIVE", email: "developer@local", lastUsed: new Date(Date.now() - 7200000).toISOString(), type: "Studio Executive" }
      ]);
      return;
    }

    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (err) {
        console.warn("Auth initialization fallback:", err);
        try {
          await signInAnonymously(auth);
        } catch (e) {
          console.error("Anonymous sign in failed:", e);
        }
      }
    };

    initAuth();
    const unsub = onAuthStateChanged(auth, setUser);
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!firebaseReady || !user) return;
    const writeLog = async () => {
      try {
        const email = user.email || `director-${user.uid.substring(0, 5)}@ai.com`;
        const logRef = doc(db, 'artifacts', appId, 'public', 'data', 'users_log', user.uid);
        await setDoc(logRef, {
          uid: user.uid,
          email,
          lastUsed: new Date().toISOString(),
          type: 'Google AI Pro Account'
        }, { merge: true });
      } catch (e) {
        console.warn("Log write error:", e);
      }
    };
    writeLog();
  }, [user]);

  useEffect(() => {
    if (!firebaseReady || !user) return;
    const logCol = collection(db, 'artifacts', appId, 'public', 'data', 'users_log');
    const unsub = onSnapshot(logCol, (snapshot) => {
      const logs = [];
      snapshot.forEach(d => logs.push(d.data()));
      logs.sort((a, b) => new Date(b.lastUsed) - new Date(a.lastUsed));
      setUserLogs(logs);
    }, err => console.warn(err));
    return () => unsub();
  }, [user]);

  if (!hasEntered) {
    return (
      <div 
        className="flex flex-col items-center justify-center min-h-screen w-full bg-[#070b14] relative overflow-hidden px-4"
        style={{ backgroundImage: `url("${TECH_GRID_SVG}")`, backgroundSize: '60px' }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#050811] via-transparent to-[#050811]/70 pointer-events-none" />
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 text-center space-y-8 max-w-2xl w-full p-8 sm:p-12 rounded-3xl bg-[#0a0f1d]/80 border border-cyan-800/40 backdrop-blur-xl shadow-2xl shadow-cyan-950/50">
          <div className="inline-flex p-4 rounded-2xl bg-gradient-to-br from-cyan-500 to-teal-400 shadow-xl shadow-cyan-500/25 text-[#050b14]">
            <Clapperboard size={48} strokeWidth={2.5} />
          </div>

          <div className="space-y-3">
            <span className="text-[11px] font-bold text-amber-400 tracking-widest uppercase px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30">
              NEXT-GEN AI PRODUCTION ENVIRONMENT
            </span>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-tight font-sans">
              OG AI <br />
              <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-amber-300 bg-clip-text text-transparent">
                DIRECTOR PRO
              </span>
            </h1>
            <p className="text-gray-400 text-xs sm:text-sm max-w-md mx-auto leading-relaxed">
              Studio orkestrasi konten profesional berbasis AI. Hasilkan naskah afiliasi konversi tinggi, prompt sinematik, first frame photorealistic, dan visual storyboard otomatis.
            </p>
          </div>

          <div className="pt-2">
            <button 
              onClick={() => setHasEntered(true)}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-[#050b14] font-black text-base rounded-2xl shadow-xl shadow-cyan-500/30 transform active:scale-95 transition-all cursor-pointer"
            >
              MASUK KE STUDIO SUTRADARA <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  const ActiveComponent = TABS.find(t => t.id === activeTab)?.component || TABS[0].component;

  return (
    <div 
      className="flex h-screen w-full bg-[#070b14] text-gray-100 font-sans overflow-hidden selection:bg-cyan-500/30"
      style={{ backgroundImage: `url("${TECH_GRID_SVG}")`, backgroundSize: '60px' }}
    >
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/80 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside 
        className={`fixed md:relative z-50 h-full bg-[#0a0f1d]/90 border-r border-cyan-950/80 transition-all duration-300 flex flex-col backdrop-blur-xl
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          ${sidebarCollapsed ? 'w-20' : 'w-72'}
        `}
      >
        <div className="p-5 flex items-center justify-between border-b border-cyan-950 h-20 shrink-0">
          {!sidebarCollapsed ? (
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-400 flex items-center justify-center shrink-0 text-[#050b14] shadow-md shadow-cyan-500/30">
                <Clapperboard size={20} strokeWidth={2.5} />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-black text-sm tracking-tight text-white truncate">OG AI</span>
                <span className="text-[10px] text-cyan-400 font-bold tracking-wider uppercase">Director Pro</span>
              </div>
            </div>
          ) : (
            <div className="w-9 h-9 mx-auto rounded-xl bg-gradient-to-br from-cyan-500 to-teal-400 flex items-center justify-center text-[#050b14]">
              <Clapperboard size={20} strokeWidth={2.5} />
            </div>
          )}
          <button className="md:hidden text-gray-400 hover:text-white" onClick={() => setSidebarOpen(false)}>
            <X size={22} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1.5 custom-scrollbar">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSidebarOpen(false); }}
                className={`relative flex items-center gap-3.5 px-3.5 py-3 rounded-xl transition-all w-full text-left group cursor-pointer
                  ${isActive 
                    ? 'bg-cyan-500/10 text-white font-extrabold border border-cyan-500/30 shadow-inner' 
                    : 'text-gray-400 hover:bg-[#0f172a]/60 hover:text-cyan-200 border border-transparent'}
                  ${sidebarCollapsed ? 'justify-center px-0' : ''}
                `}
                title={sidebarCollapsed ? tab.title : ''}
              >
                {isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-7 bg-cyan-400 rounded-r-full shadow-md shadow-cyan-400" />
                )}
                <Icon size={20} className={`shrink-0 ${isActive ? 'text-cyan-400' : 'group-hover:text-cyan-300'}`} />
                {!sidebarCollapsed && (
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold truncate">{tab.title}</span>
                    <span className="text-[10px] text-gray-500 uppercase tracking-wider">{tab.subtitle}</span>
                  </div>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-cyan-950 hidden md:flex justify-center">
          <button 
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="p-2 bg-[#0d1424] text-gray-400 hover:text-cyan-300 rounded-xl border border-cyan-950 transition-colors cursor-pointer"
          >
            {sidebarCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        <header className="md:hidden flex items-center justify-between p-4 border-b border-cyan-950 bg-[#0a0f1d]/90 backdrop-blur-md sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="p-2 text-cyan-400 bg-[#0d1424] rounded-xl border border-cyan-950">
            <Menu size={20} />
          </button>
          <div className="font-black text-xs text-white uppercase tracking-wider flex items-center gap-1.5">
            <span className="text-cyan-400">OG AI</span> • {TABS.find(t => t.id === activeTab)?.title}
          </div>
          <div className="w-8"></div>
        </header>

        <header className="hidden md:flex h-20 items-center justify-between px-8 border-b border-cyan-950/80 bg-[#0a0f1d]/60 backdrop-blur-md shrink-0">
          <div>
            <h2 className="text-xl font-black text-white flex items-center gap-3">
              {TABS.find(t => t.id === activeTab)?.title}
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 uppercase tracking-widest font-mono font-bold">
                {TABS.find(t => t.id === activeTab)?.subtitle}
              </span>
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">Konfigurasi sutradara kreatif dan eksekusi rendering visual instan.</p>
          </div>
          <div className="flex items-center gap-2"></div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto pb-16">
            <ActiveComponent />
          </div>
        </div>
      </main>

      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #164e63; border-radius: 9999px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #0891b2; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes zoomIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
        
        .animate-in { animation-duration: 0.3s; animation-fill-mode: both; animation-timing-function: cubic-bezier(0.16, 1, 0.3, 1); }
        .fade-in { animation-name: fadeIn; }
        .zoom-in { animation-name: zoomIn; }
      `}} />
    </div>
  );
}